from rssd.VSG.Common import VSG
import time


class GnssConduction(VSG):
    def __init__(self, ip_addr):
        super(VSG, self).__init__()
        self.jav_Open(ip_addr)
        print(f"Instrument information: {self.query("*IDN?")}")
        """awgn is Set to be off by default"""
        self.write(":SOURce1:AWGN:STATe 0")

    def Set_baseband_state(self, sState="ON"):
        if sState in (1, '1', 'ON'):
            self.write(':SOURce1:BB:GNSS:STATe ON')
        elif sState in (0, '0', 'OFF'):
            self.write(':SOURce1:BB:GNSS:STATe OFF')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Set_Digital_attenuation(self, level=0):
        """

        :param level: a number from -3.522 to 80
        :return:
        """
        self.write(f':SOURce1:POWer:ATTenuation:DIGital {level}')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_baseband_state(self):
        return self.query(':SOURce1:BB:GNSS:STATe?')

    def Set_l5_state(self, state="ON"):
        self.write(f':SOURce1:BB:GNSS:L5Band:STATe {state}')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_l5_state(self):
        return self.query(':SOURce1:BB:GNSS:L5Band:STATe?')

    def Set_Galileo_state(self, state="ON"):
        if state in (1, '1', 'ON'):
            self.write(f':SOURce1:BB:GNSS:SYSTem:GALileo:STATe ON')
        elif state in (0, '0', 'OFF'):
            self.write(f':SOURce1:BB:GNSS:SYSTem:GALileo:STATe OFF')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_Galileo_state(self):
        return self.query(':SOURce1:BB:GNSS:SYSTem:GALileo:STATe?')

    """TODO: define Get"""

    def Set_GPS(self, state="ON"):
        if state in (1, '1', 'ON'):
            self.write(f':SOURce1:BB:GNSS:SYSTem:GPS:STATe ON')
        elif state in (0, '0', 'OFF'):
            self.write(f':SOURce1:BB:GNSS:SYSTem:GPS:STATe OFF')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_GPS_state(self):
        return self.query(':SOURce1:BB:GNSS:SYSTem:GPS:STATe?')

    def Set_Beidou(self, state="ON"):
        if state in (1, '1', 'ON'):
            self.write(f':SOURce1:BB:GNSS:SYSTem:BEIDou:STATe ON')
        elif state in (0, '0', 'OFF'):
            self.write(f':SOURce1:BB:GNSS:SYSTem:BEIDou:STATe OFF')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Gett_Beidou_state(self):
        return self.query(':SOURce1:BB:GNSS:SYSTem:BEIDou:STATe?')

    def Set_GLonass(self, state="ON"):
        if state in (1, '1', 'ON'):
            self.write(f':SOURce1:BB:GNSS:SYSTem:GLOnass:STATe ON')
        elif state in (0, '0', 'OFF'):
            self.write(f':SOURce1:BB:GNSS:SYSTem:GLOnass:STATe OFF')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_GLonass_state(self):
        return self.query(':SOURce1:BB:GNSS:SYSTem:GLONass:STATe?')

    def Set_Power(self, power=-130):
        self.write(f':SOURce1:BB:GNSS:POWer:REFerence {power}')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_Power(self):
        return self.query(':SOURce1:BB:GNSS:POWer:REFerence?')
    
    def Set_Noise_state(self, state="ON"):
        if state in (1, '1', 'ON'):
            self.write(':SOURce1:AWGN:STATe ON')
        elif state in (0, '0', 'OFF'):
            self.write(':SOURce1:AWGN:STATe OFF')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_Noise_state(self):
        return self.query(':SOURce1:AWGN:STATe?')
            
    def Set_Noise_Type(self, noise="AWGN"):
        """
        :param noise: 'CW' or 'AWGN'
        :return:
        """
        self.write(f'SOURce1:AWGN:MODE {noise}')
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_Noise_Type(self):
        return self.query("SOURce1:AWGN:MODE?")

    def Set_CW_Freq_OffSet(self, offSet=0.0):
        if self.Get_Noise_Type() == "CW":
            self.write(f'SOURce1:AWGN:FREQuency:TARGet {offSet}')
        else:
            print("The noise type is not CW, please check!")
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_CW_Freq_OffSet(self):
        return self.query("SOURce1:AWGN:FREQuency:TARGet?")

    def Set_AWGN_OffSet_and_Bandwidth(self, offSet=0.0, bandwidth=1e6):
        if self.Get_Noise_Type() == "ADD":
            self.write(f'SOURce1:AWGN:FREQuency:CENTer:OFFSet {offSet}')
            self.write(f'SOURce1:AWGN:BWIDth {bandwidth}')
        else:
            print("The noise type is not AWGN, please check!")
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_AWGN_OffSet_and_Bandwidth(self):
        return (self.query('SOURce1:AWGN:FREQuency:CENTer:OFFSet?'),
                self.query('SOURce1:AWGN:BWIDth?'))

    def Set_CNRatio(self, ratio=30):
        self.write("SOURce1:AWGN:DISP:MODE RFA")
        self.write("SOURce1:AWGN:POWer:RMODe CARR")
        self.write(f"SOURce1:AWGN:CNRatio {ratio}")
        while self.query("*OPC?") != '1':
            time.sleep(0.01)

    def Get_CNRatio(self):
        return self.query("SOURce1:AWGN:CNRatio?")

    # def Configure_AWGN_jamming_test(self):

    def Close(self):
        self.jav_Close()
