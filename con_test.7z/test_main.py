import timeit

import serial
from RsInstrument import *
import sys
import time
import os
import xlwings as xw
from datetime import datetime
import openpyxl
import pyvisa as visa
from nmea_parser import parse_nmea_sentences, get_gnss_fix_status
from smbv import GnssConduction
import numpy as np
from cmw import BluetoothSignaling, WifiSignaling
from collections import defaultdict
import pandas as pd
from openpyxl.utils import get_column_letter
import tkinter as tk
from tkinter import filedialog
import shutil

port = "COM3"
baud_rate = 921600
instr = ''
ser = None
bt_sig_test = None
wifi_sig_test = None
gnss_test = None
bt_power0 = -80
bt_power_scalar = defaultdict(list)
bt_sensitivity = defaultdict(list)
bt_modulation = defaultdict(list)
bt_PacketType_BurstType = {
        'BR': ['DH1', 'DH3', 'DH5'],
        'EDR': ['E21P', 'E25P', 'E35P']
    }
bt_PacketTypes_for_print = {'DH1': 'DH1', 'DH3': 'DH3', 'DH5': 'DH5',
                          'E21P': '2-DH1', 'E25P': '2-DH5', 'E35P': '3-DH5'}
bt_pattern_sheet = {'PRBS9': ['Tx_power_PRBS9', 'Tx_bt_modulation_PRBS9'],
                 'P11': ['Tx_power_10101010', 'Tx_bt_modulation_10101010'],
                 'P44': ['Tx_power_11110000', 'Tx_bt_modulation_11110000']}
bt_column_index_for_ChannelType = {1: 'F', 3: 'H', 79: 'CF'}
bt_measure_tx_or_rx = {'1': 'Tx', '2': 'Rx', '3': 'Tx and Rx'}
bt_rf_file = 'RF_conduction_template.xlsx'
bt_column_num = 3


def check_instrument_info():
    print("Please make sure IP address of your test instrument starts with 192.168.1.xxx!\n")
    rm = visa.ResourceManager("@py")
    ip_str = rm.list_resources()
    print(f'Available resources: {ip_str}')
    items_num = len(ip_str)
    ip_address = ip_str[items_num-1].split('::')[1]
    print(f'The IP address of the remote instrument is: {ip_address}')
    # 连接到rmt_server
    # cmw = RsInstrument('TCPIP::192.168.1.110::hislip0', reset=False)
    rmt_server = rm.open_resource(rm.list_resources()[items_num-1])
    rmt_server.clear()
    rmt_server.timeout = 3000
    rmt_server.write('SYST:DISP:UPD ON')
    instrument_info = rmt_server.query("*IDN?")
    rmt_server.close()
    # print(f"The instrument is :{instrument_info}")
    if "CMW" in instrument_info:
        return "CMW500", ip_address
    elif "SMBV" in instrument_info:
        return "SMBV100B", ip_address


def get_bt_modulation_by_channel(burst_type='BR', channel=0):
    bt_sig_test.Set_Channels(channel, 0)
    bt_sig_test.Set_BurstType(burst_type)
    bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
    bt_sig_test.Set_PacketType(bt_sig_test.packet_type)
    return bt_sig_test.Read_MEvaluation_ModulationScalar()


def get_bt_modulationScalar(channel='0'):
    """

    :param channel: 'all' for all ch; 'lmh' for low_mid_high ch; specific number for certain ch, like '0' for ch 0
    :return: a dict for Tx bt_modulation
    """
    if channel.isdigit():
        channel_range = [float(channel)]
    elif channel.upper() == 'LMH':
        channel_range = range(0, 79, 39)
    elif channel.upper() == 'ALL':
        channel_range = range(0, 79, 1)
    else:
        raise ValueError("Invalid mode or channel argument")

    for channel in channel_range:
        for burst_type, packet_types in bt_PacketType_BurstType.items():
            for packet_type in packet_types:
                bt_sig_test.Set_BurstType(burst_type)
                bt_sig_test.Set_PacketType(packet_type)
                bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
                ch_str = f'CH{channel}'
                bt_modulation[ch_str].extend(get_bt_modulation_by_channel(burst_type, channel))


def get_bt_powerScalar_by_channel(burst_type='BR', channel=0):
    bt_sig_test.Set_Channels(channel, 0)
    bt_sig_test.Set_BurstType(burst_type)
    bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
    bt_sig_test.Set_PacketType(bt_sig_test.packet_type)
    return bt_sig_test.Read_MEvaluation_PowerScalar()


def get_bt_powerScalar(channel='0'):
    """

    :param channel: 'all' for all ch; 'lmh' for low_mid_high ch; specific number for certain ch, like '0' for ch 0
    :return: a dict for Tx Power scalar
    """
    if channel.isdigit():
        channel_range = [float(channel)]
    elif channel.upper() == 'LMH':
        channel_range = range(0, 79, 39)
    elif channel.upper() == 'ALL':
        channel_range = range(0, 79, 1)
    else:
        raise ValueError("Invalid mode or channel argument")

    for channel in channel_range:
        for burst_type, packet_types in bt_PacketType_BurstType.items():
            for packet_type in packet_types:
                bt_sig_test.Set_BurstType(burst_type)
                bt_sig_test.Set_PacketType(packet_type)
                bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
                ch_str = f'CH{channel}'
                bt_power_scalar[ch_str].extend(get_bt_powerScalar_by_channel(burst_type, channel))


def get_bt_tx_results_by_channel(burst_type='BR', channel=0):
    bt_sig_test.Set_Channels(channel, 0)
    bt_sig_test.Set_BurstType(burst_type)
    bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
    bt_sig_test.Set_PacketType(bt_sig_test.packet_type)
    return bt_sig_test.Read_MEvaluation_PowerScalar(), bt_sig_test.Read_MEvaluation_ModulationScalar()


def get_bt_tx_results(channel='0'):
    global bt_column_num
    if channel.isdigit():
        channel_range = [float(channel)]
        bt_column_num = 1
    elif channel.upper() == 'LMH':
        channel_range = range(0, 79, 39)
        bt_column_num = 3
    elif channel.upper() == 'ALL':
        channel_range = range(0, 79, 1)
        bt_column_num = 79
    else:
        raise ValueError("Invalid mode or channel argument")
    # 由于直接测量完BR后直接测量EDR会导致EDR数据偏高，需要在BR模式数据测量完毕后，关闭bt_signal后再打开，才能测量EDR
    for burst_type, packet_types in bt_PacketType_BurstType.items():
        for channel in channel_range:
            print(
                f"\n>>>>>>>>>>>>>>>>>>Channel {channel} test begins at {datetime.now().now()}<<<<<<<<<<<<<<<<")
            print(f"\n.................................Burst type {burst_type} "
                  f"is under test...................................")
            for packet_type in packet_types:
                bt_sig_test.Set_BurstType(burst_type)
                bt_sig_test.Set_PacketType(packet_type)
                print(f"********************************Packet type {bt_PacketTypes_for_print[packet_type]} "
                      f"is under test**********************************")
                bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
                ch_str = f'CH{channel}'
                power_data, bt_modulation_data = get_bt_tx_results_by_channel(burst_type, channel)
                bt_power_scalar[ch_str].extend(power_data)
                bt_modulation[ch_str].extend(bt_modulation_data)
        # bt_sig_test.Set_State('OFF')
        # time.sleep(0.1)
        # bt_sig_test.Set_State('ON')
        # connect_bt_eut()connect_bt_eut
        bt_sig_test.Set_TestMode_state(state='DET')
        bt_sig_test.Set_TestMode_state(state='TMC')

    # for channel in channel_range:
    #     print(f"\n>>>>>>>>>>>>>>>>>>Channel {channel} test begins at begins at {datetime.now().now()}<<<<<<<<<<<<<<<<")
    #     for burst_type, packet_types in bt_PacketType_BurstType.items():
    #         print(f"\n.................................Burst type {burst_type} "
    #               f"is under test...................................")
    #         for packet_type in packet_types:
    #             bt_sig_test.Set_BurstType(burst_type)
    #             bt_sig_test.Set_PacketType(packet_type)
    #             print(f"********************************Packet type {bt_PacketTypes_for_print[packet_type]} "
    #                   f"is under test**********************************")
    #             bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
    #             ch_str = f'CH{channel}'
    #             power_data, bt_modulation_data = get_bt_tx_results_by_channel(burst_type, channel)
    #             bt_power_scalar[ch_str].extend(power_data)
    #             bt_modulation[ch_str].extend(bt_modulation_data)


def get_bt_sensitivity(channel='0'):
    """

    :param channel: 'all' for all ch; 'lmh' for low_mid_high ch; specific number for certain ch, like '0' for ch 0
    :return: a dict for Rx bt_sensitivity
    """
    if channel.isdigit():
        channel_range = [float(channel)]
    elif channel == 'lmh':
        channel_range = range(0, 79, 39)
    elif channel == 'all':
        channel_range = range(0, 79, 1)
    else:
        raise ValueError("Invalid mode or channel argument")

    for channel in channel_range:
        for burst_type, packet_types in bt_PacketType_BurstType.items():
            bt_sig_test.Set_BurstType(burst_type)
            bt_sig_test.Set_PacketType(bt_PacketType_BurstType[burst_type][0])
            bt_sig_test.Set_PatternType('PRBS9')
            ch_str = f'CH{channel}'
            bt_sensitivity[ch_str].append(get_bt_sensitivity_by_channel(burst_type, channel))
            # for packet_type in packet_types:
            #     bt_sig_test.Set_PacketType(packet_type)
            #     bt_sig_test.Set_BurstType(burst_type)
            #     bt_sig_test.Set_PatternType(bt_PacketTypes_for_print[burst_type][0])
            #     ch_str = f'CH{channel}'
            #     bt_sensitivity[ch_str].append(get_bt_sensitivity_by_channel(burst_type, channel))


def get_bt_sensitivity_for_all_channels():
    for burst_type in ['BR', 'EDR']:
        for channel in range(0, 79):
            ch_str = 'CH'+str(channel)
            if ch_str not in list(bt_sensitivity.keys()):
                bt_sensitivity[ch_str] = []
            bt_sensitivity[ch_str].append(get_bt_sensitivity_by_channel(burst_type, channel))


def get_bt_sensitivity_for_lmh_channels():
    # ch_list = [0, 39, 78]
    for burst_type in ['BR', 'EDR']:
        for channel in range(0, 79, 39):
            ch_str = 'CH' + str(channel)
            if ch_str not in list(bt_sensitivity.keys()):
                bt_sensitivity[ch_str] = []
            bt_sensitivity[ch_str].append(get_bt_sensitivity_by_channel(burst_type, channel))


def get_bt_sensitivity_for_specific_channel(channel):
    # ch_list = channel
    for burst_type in ['BR', 'EDR']:
        ch_str = 'CH' + str(channel)
        if ch_str not in list(bt_sensitivity.keys()):
            bt_sensitivity[ch_str] = []
        bt_sensitivity[ch_str].append(get_bt_sensitivity_by_channel(burst_type, channel))


def get_bt_sensitivity_by_channel(burst_type="BR", channel=0):
    global bt_power0
    power = bt_power0
    bt_sig_test.Set_Tx_level(power)
    bt_sig_test.Set_BurstType(burst_type)
    bt_sig_test.Set_PacketType(bt_PacketType_BurstType[burst_type][0])
    bt_sig_test.Set_PatternType('PRBS9')

    last_step = 3
    print(f"----Channel: {channel}, Mode: {burst_type} test begins at {datetime.now().now()}------")
    bt_sig_test.Set_Channels(0, channel)
    while True:
        print(f"***Set Tx_level: {round(power, 2)}dBm")
        bt_sig_test.Set_Tx_level(power)
        # time.sleep(2)
        cur_step, ber = get_bt_power_step()

        print(f"***Current ber is: {round(ber, 3)}%")
        print(f"***Power step: {-round(cur_step, 2)}dB\n")
        if -0.2 < last_step*cur_step < 0:
            if last_step > 0:
                bt_power0 = power+last_step
                # return bt_power0
            elif last_step < 0:
                bt_power0 = power
                # return bt_power0
            return bt_power0
        last_step = cur_step
        power = power - cur_step


def get_bt_power_step():

    if bt_sig_test.burst_type == 'BR':
        err = 0.1
    elif bt_sig_test.burst_type == 'EDR':
        err = 0.01
    elif bt_sig_test.burst_type == 'LE':
        err = 10
    else:
        err = 0
    """
    wait until the rx_quality state becomes "rdy", read 3 times when BER != 0.0
    """
    ber0 = get_bt_ber()
    """
    when ber == 0.0, set power step to be 3 db, the power should decrease by 3 db
    """
    if ber0 < 1e-6:
        return 3.0, ber0
    """
    when ber != 0.0, read 2 more times
    """
    ber1 = get_bt_ber()
    ber2 = get_bt_ber()

    ber = [ber0, ber1, ber2]
    ber_arr = np.array(ber)
    if np.all(ber_arr <= err/5):
        power_step = 1.0
    elif np.any(ber_arr > err/5) and np.all(ber_arr <= err/2):
        power_step = 0.5
    elif np.any(ber_arr > err/2) and np.all(ber_arr <= err):
        power_step = 0.2
    elif np.any(ber_arr > err) and np.all(ber_arr <= 2*err):
        power_step = -0.5
    elif np.any(ber_arr >= 2*err):
        power_step = -1.0
    else:
        power_step = None
    return power_step, max(ber)


def get_bt_ber():
    ber_result = bt_sig_test.Read_RxQuality_BER().split(',')
    ber = float(ber_result[1])
    return ber


def bt_rx_test(channel='all'):
    print(f"--------------------Rx test begins at {datetime.now().now()}--------------------")
    bt_sig_test.Set_PatternType('PRBS9')
    get_bt_sensitivity(channel)
    print(bt_sensitivity)
    df_sens = pd.DataFrame.from_dict(bt_sensitivity)
    with pd.ExcelWriter(bt_rf_file, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
        df_sens.to_excel(writer, sheet_name='Rx_bt_sensitivity', startrow=2, index=False)
    bt_sig_test.Close()


def bt_tx_test(channel_type='all'):
    bt_sig_test.Set_MEvaluation_All_Off()
    bt_sig_test.Set_MEvaluation_FrequencyDeviation_state('ON')
    bt_sig_test.Set_MEvaluation_PowerScalar_state('ON')
    bt_sig_test.Set_MEvaluation_ModulationScalar_state('ON')
    print(f"--------------------Tx test is in progress begins at {datetime.now().now()}------------------")
    global bt_power_scalar, bt_modulation
    for pt, sheet_list in bt_pattern_sheet.items():
        print(f"\n~~~~~~~~~~~~~~~~~~~~Pattern type {pt} test begins at {datetime.now().now()}~~~~~~~~~~~~~~~")
        df_measurements = []
        bt_sig_test.Set_PatternType(pt)
        get_bt_tx_results(channel_type)
        df_bt_power = pd.DataFrame.from_dict(bt_power_scalar)
        df_bt_power.insert(loc=0, column='Average', value=df_bt_power.mean(axis=1))
        df_bt_modulation = pd.DataFrame.from_dict(bt_modulation)
        df_bt_modulation.insert(loc=0, column='Average', value=df_bt_modulation.mean(axis=1))
        df_measurements.append(df_bt_power)
        df_measurements.append(df_bt_modulation)

        with pd.ExcelWriter(bt_rf_file, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
            # df_power.to_excel(writer, sheet_name=sheet, startrow=0, startcol=4, index=False)
            for i in range(2):
                df_measurements[i].to_excel(writer, sheet_name=sheet_list[i], startrow=0, startcol=4, index=False)
        bt_power_scalar = defaultdict(list)
        bt_modulation = defaultdict(list)
    bt_sig_test.Close()
    """Formatting tx and rx data"""
    wb = xw.Book(bt_rf_file)
    for sheet in wb.sheet_names:
        ws = wb.sheets[sheet]
        ws.range('E2:CE40').number_format = '0.000'
        ws.range('A1:CE40').api.HorizontalAlignment = -4108
        ws.range('A1:CE40').columns.autofit()
        ws.range('E1:E40').api.Font.Bold = True
        row_num = ws.range('F1').current_region.last_cell.row - 1
        for i in range(1, row_num + 1):
            row_data = ws.range(f'F{i + 1}:{bt_column_index_for_ChannelType[bt_column_num]}{i + 1}').value
            max_column_letter = get_column_letter(row_data.index(max(row_data)) + 6)
            min_column_letter = get_column_letter(row_data.index(min(row_data)) + 6)
            ws.range(f'{max_column_letter}{i + 1}').color = (255, 255, 0)
            ws.range(f'{max_column_letter}{i + 1}').api.Font.Bold = True
            ws.range(f'{min_column_letter}{i + 1}').color = (0, 255, 0)
            ws.range(f'{min_column_letter}{i + 1}').api.Font.Bold = True
    wb.save()
    wb.close()
    xw.App().quit()


def bt_test(measurement_type='1', channel_type='all'):
    measurement_actions = {
        '1': lambda: bt_tx_test(channel_type),
        '2': lambda: bt_rx_test(channel_type),
        '3': lambda: (bt_tx_test(channel_type), bt_rx_test(channel_type))
    }

    try:
        measurement_actions[measurement_type]()
    except KeyError:
        raise ValueError(f'Invalid measurement type: {measurement_type}')


def connect_bt_eut():
    eut_state = bt_sig_test.Get_EUT()
    if not eut_state:
        print('Time out, please check the state of your device')
    else:
        print(f'Eut BTAddress is: {eut_state}')
        bt_sig_test.Set_PageTarget()
        # bt_sig_test.Set_TestMode()
        bt_sig_test.Set_TestMode_state()
        while bt_sig_test.Get_Connection_State() != 'TCON':
            print(bt_sig_test.Get_Connection_State(), end=',')
            time.sleep(1)
            print(bt_sig_test.Get_Connection_State(), end=',')
    print('')


def create_report():
    global bt_rf_file
    # src_file0 = '//nas.local/DATA/Wireless/AntennaTest/Templates/Latest/RF_conduction_template.xlsx'
    src_file0 = '//D/Templates/RF_conduction_template.xlsx'
    # src_file1 = '//10.0.0.5/DATA/Wireless/AntennaTest/Templates/Latest/RF_conduction_template.xlsx'
    src_file1 = '//D/Templates/RF_conduction_template.xlsx'
    print("*******************************************************************\n")
    print("========Formatting and writing test results to an xlsx file========\n")
    print('*******Please select a directory to store your test reports********\n')
    time.sleep(2.0)
    source_file_path = filedialog.askdirectory(title='Select storage directory')
    if source_file_path == '':
        print('No directory selected, please choose one. Cancelling the selection, '
              'you will go back to the channel menu')
        source_file_path = filedialog.askdirectory(title='Select storage directory')
    if source_file_path == '':
        return False
    print(f"The report file directory is {source_file_path}\n")
    excel_name = input("========Please enter the report name (35 characters or less)========\n")
    if excel_name == '':
        print('Name is missing, please type the report file name again. '
              'Wrong input returns to channel menu\n')
        excel_name = input("========Please enter the report name========\n")
    if len(excel_name) > 35:
        print('Name too long, must be under 35 characters. '
              'Wrong input returns to channel menu\n')
        excel_name = input("========Please enter the report name========\n")
    if '.' in excel_name:
        print('Name has a ".", please retype the report name. '
              'Wrong input returns to channel menu\n')
        excel_name = input("========Please enter the report name========\n")
    if excel_name == '' or len(excel_name) > 35 or '.' in excel_name:
        return False
    target_file = f'{source_file_path}/{excel_name}.xlsx'
    bt_rf_file = target_file
    # if the file has existed, delete the file
    if os.path.exists(target_file):
        print('File already exists. It will be replaced with test data. Yes(y) or No(n)')
        if_delete = input()
        if if_delete == 'n':
            return False
        os.remove(target_file)
    try:
        shutil.copyfile(src_file0, target_file)
    except:
        shutil.copyfile(src_file1, target_file)
    time.sleep(0.5)
    return True


gps_tracking_wait_time = 30
gps_acquiring_wait_time = 30
gps_ttff_wait_time = 30
attenuation = 30
time_schedule = [780, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 120, 120, 120, 60, 60, 60, 60, 60]
power_table = [-130, -140, -150, -155, -156, -157, -158, -159, -160, -160.5, -161, -161.5, -162, -162.5, -163,
               -163.5, -164, -164.5, -165, -165.5, -166, -166.5, -167, 167.5, 168]


def gps_get_ttff(start_mode='cold', power=-130):
    """

    :param start_mode: 'hot' or 'cold'
    :param power: -145 -- -110
    :return:
    """
    global gnss_test
    """Initiate smbv100b and set dual-band mode"""
    gnss_test = GnssConduction(ip_addr)
    gnss_test.write("*RST")
    gnss_test.Set_l5_state('ON')
    gnss_test.Set_baseband_state('ON')
    gnss_test.Set_IQMod('ON')
    gnss_test.Set_Digital_attenuation(level=attenuation)
    gnss_test.Set_RFState('ON')

    """In warm start test, positioning for 13 minutes is a must"""
    ser = serial.Serial(port=port, baudrate=baud_rate)
    if start_mode != 'cold':
        gnss_test.Set_Power(int(-130 + attenuation))
        ser.write(b'$PAIR006*3C\r\n')
        print(
            f"\n*********Set gps power {float(gnss_test.Get_Power()) - attenuation}dBm and wait"
            f" 780 secs............")
        time.sleep(780)
    ttff_all = []
    ttff = 0
    gnss_test.Set_Power(power+attenuation)
    for i in range(20):
        print(f"-----------test loop {i+1}--------------")
        print(f"********{start_mode} start the gnss chip")
        if start_mode == 'cold':
            ser.write(b'$PAIR006*3C\r\n')
        elif start_mode == 'hot':
            ser.write(b'$PAIR004*3E\r\n')
        start = timeit.default_timer()
        ser.reset_input_buffer()
        while not get_gnss_fix_status(ser, fix_time=1):
            print('************GNSS status: Not fixed!')
        print('************GNSS status: Fixed!')
        stop = timeit.default_timer()
        ttff_single = stop-start
        ttff_all.append(ttff_single)
        ttff = ttff+ttff_single
        print(f"*********ttff at test loop_{i} at {start_mode} start is {round(ttff_single, 2)}s\n")
    print(f"############# The final ttff is: {round(ttff/20, 2)}s with power {power}dBm ################")
    return ttff/20


def gps_get_acquiring_sensitivity(start_mode='cold'):
    """
    :param: start_mode = 'hot','warm' or 'cold'
    :return: acquiring sensitivity at hot, warm or cold start
    """
    print(f"------------------Test acquiring sensitivity at {start_mode} start-------------------")
    global power_table, gnss_test, ser
    # attenuation = 20
    # time_schedule = [80, 60, 60, 60, 60, 60, 60, 60, 60, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]
    acquiring_power_table_at_cold_start = [-152, -151, -150, -149.5, -149, -148.5, -148, -147.5, -147, -146.5,
                                           -146, -145.5, -145, -144.5, -144, -143.5, -143, -142.5, -142, -141.5]
    acquiring_power_table_at_cold_start = [i+attenuation for i in acquiring_power_table_at_cold_start]
    acquiring_power_table_at_warm_start = [i-5 for i in acquiring_power_table_at_cold_start]
    acquiring_power_table_at_hot_start = [i-15 for i in acquiring_power_table_at_cold_start]
    acquiring_power_table = {'cold': acquiring_power_table_at_cold_start, 'warm': acquiring_power_table_at_warm_start,
                             'hot': acquiring_power_table_at_hot_start}
    """Initiate smbv100b and set dual-band mode"""
    gnss_test = GnssConduction(ip_addr)
    gnss_test.write("*RST")
    gnss_test.Set_l5_state('ON')
    gnss_test.Set_baseband_state('ON')
    gnss_test.Set_IQMod('ON')
    gnss_test.Set_Digital_attenuation(level=attenuation)
    gnss_test.Set_RFState('ON')

    """In warm or hot start test, positioning for 13 minutes is a must"""
    ser = serial.Serial(port=port, baudrate=baud_rate)
    if start_mode != 'cold':
        gnss_test.Set_Power(int(-130 + attenuation))
        ser.write(b'$PAIR006*3C\r\n')
        print(
            f"\n*********Set gps power {float(gnss_test.Get_Power()) - attenuation}dBm and wait"
            f" {time_schedule[0]} secs............")
        time.sleep(time_schedule[0])
    step = 0
    gnss_test.Set_Power(acquiring_power_table[start_mode][step])
    print(f"\n*********Set gps power {float(gnss_test.Get_Power()) - attenuation}dBm............")
    if start_mode == 'cold':
        print(f"**********Cold start, wait {time_schedule[0]} secs at the beginning")
        time.sleep(time_schedule[0])
    time.sleep(1)
    print(f"\n********{start_mode} start the gnss chip\n")
    if start_mode == 'cold':
        ser.write(b'$PAIR006*3C\r\n')
    elif start_mode == 'warm':
        ser.write(b'$PAIR005*3F\r\n')
    elif start_mode == 'hot':
        ser.write(b'$PAIR004*3E\r\n')
    time.sleep(2)
    print(f'Frequency: {gnss_test.Get_Freq() / 1e9}GHz')
    # gnss_test.Set_Freq(1.389225e9)
    print(f'L5 state: {gnss_test.Get_l5_state()}')
    print(f'GPS Power: {gnss_test.Get_Power()}dBm')
    print(f'CNR: {gnss_test.Get_CNRatio()}')
    ser.reset_input_buffer()

    # fix_interval = 5
    while not get_gnss_fix_status(ser, fix_time=5):
        print(f'********{datetime.now().now()}GNSS fix status: not fixed')
        step = step + 1
        # fix_interval = step*3
        # power = acquiring_power_table_at_cold_start[step]
        power = acquiring_power_table[start_mode][step]
        gnss_test.Set_Power(power)
        print(f'\n*********Set GPS Power: {float(gnss_test.Get_Power()) - attenuation}dBm and wait '
              f'{time_schedule[step]} secs......')
        time.sleep(time_schedule[step])
        ser.reset_input_buffer()
    print('********GNSS fix status: fixed!')
    sensitivity = acquiring_power_table[start_mode][step]
    ser.reset_input_buffer()
    sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
    print(f"\n**********Acquiring sensitivity at {start_mode} start mode: {sensitivity-attenuation}dBm")
    print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBm")
    print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBm\n")
    ser.close()
    gnss_test.Close()
    return sensitivity


def gps_get_tracking_sensitivity():
    """

    :return: sensitivity
    """
    global power_table, gnss_test
    print("------------------Test tracking sensitivity-------------------")

    tracking_power_table = [i+attenuation for i in power_table]
    # cold start the chip
    print("\n********Cold start the gnss chip\n")
    ser = serial.Serial(port=port, baudrate=baud_rate)
    ser.write(b'$PAIR006*3C\r\n')
    time.sleep(2)
    """Initiate smbv100b and set dual-band mode"""
    gnss_test = GnssConduction(ip_addr)
    gnss_test.write("*RST")
    gnss_test.Set_l5_state('ON')
    gnss_test.Set_baseband_state('ON')
    gnss_test.Set_IQMod('ON')
    gnss_test.Set_RFState('ON')
    gnss_test.Set_Digital_attenuation(level=attenuation)
    gnss_test.Set_Power(tracking_power_table[0])
    print(f"\n*********Set gps power {float(gnss_test.Get_Power())-attenuation}dBm and wait "
          f"{time_schedule[0]} secs............")
    time.sleep(time_schedule[0])
    print(f'Frequency: {gnss_test.Get_Freq() / 1e9}GHz')
    # gnss_test.Set_Freq(1.389225e9)
    print(f'L5 state: {gnss_test.Get_l5_state()}')
    print(f'GPS Power: {gnss_test.Get_Power()}dBm')
    print(f'CNR: {gnss_test.Get_CNRatio()}')
    step = 0
    ser.reset_input_buffer()
    interval = 5
    while not get_gnss_fix_status(ser, fix_time=interval):
        ser.reset_input_buffer()
        time.sleep(0.5)
    while get_gnss_fix_status(ser, fix_time=interval):
        print(f'********GNSS fix status: fixed')
        ser.reset_input_buffer()
        sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
        print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz")
        print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz")
        step = step + 1
        interval = step*3
        power = tracking_power_table[step]
        gnss_test.Set_Power(power)
        print(f'\n**********Set GPS Power: {float(gnss_test.Get_Power())-attenuation}dBm and'
              f' wait {time_schedule[step]} secs......')
        time.sleep(time_schedule[step])
        ser.reset_input_buffer()
    print('**********GNSS fix status: not fixed!')
    sensitivity = tracking_power_table[step-1]
    ser.reset_input_buffer()
    sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
    print(f"\n**********Tracking sensitivity: {sensitivity-attenuation}dBm")
    print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBm")
    print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBm\n")
    ser.close()
    gnss_test.Close()
    return sensitivity


if __name__ == '__main__':
    # src_file0 = '//nas.local/DATA/Wireless/AntennaTest/Templates/Latest/RF_conduction_template.xlsx'
    # src_file1 = '//10.0.0.5/DATA/Wireless/AntennaTest/Templates/Latest/RF_conduction_template.xlsx'
    # ser = serial.Serial(port=port, baudrate=baud_rate)
    # ser.write(b'$PAIR006*3C\r\n')
    # ser.close()

    instr, ip_addr = check_instrument_info()

    if instr == "SMBV100B":
        # gps_get_tracking_sensitivity()
        # gps_get_acquiring_sensitivity()
        # gps_get_acquiring_sensitivity(start_mode='warm')
        gps_get_ttff(start_mode='cold')
        # gps_get_acquiring_sensitivity(start_mode='hot')
    elif instr == 'CMW500':
        wifi_sig_test = WifiSignaling(ip_addr)
        channel_selection = 'a'
        measurement_selection = 'a'
        root = tk.Tk()
        root.withdraw()
        try:
            while measurement_selection.upper() != 'E':
                print("\n---------------------------------------------------------------------")
                print("-----------------Please select the type of measurement-----------------")
                print("-----------------------------------------------------------------------")
                print("                    1:       Tx\n")
                print("                    2:       Rx\n")
                print("                    3:       Tx and Rx\n")
                print("                    e:       Exit program")
                print('=====================================================================\n')
                measurement_selection = input("Please enter your choice for measurement type: ")
                time.sleep(0.5)
                if measurement_selection.upper() == 'E':
                    print("******************************************************************\n")
                    print('Exit the program, have a good day!!!')
                    time.sleep(5.0)
                    sys.exit('>< See you ><')
                elif measurement_selection in ['1', '2', '3']:
                    while channel_selection.upper() != 'E':
                        print("\n-------------------------------------------------------------------")
                        print("------------------Please select the type of channel------------------")
                        print("---------------------------------------------------------------------")
                        print("                    all:     All channels\n")
                        print("                    lmh:     Low_mid_high channels\n")
                        print("                    number:  Single channel\n")
                        print("                    b:       Back to to main menu\n")
                        print("                    e:       Exit program")
                        print('=====================================================================')
                        print(f'\nThe type of measurement you have chosen is {bt_measure_tx_or_rx[measurement_selection]}\n')
                        channel_selection = input("Now, pick a channel type for test: ")
                        time.sleep(0.5)
                        if channel_selection.upper() in ['ALL', 'LMH'] or channel_selection.isdigit():
                            print(f'\nMeasurement type is {bt_measure_tx_or_rx[measurement_selection]}, '
                                  f'test channel is {channel_selection.lower()}\n')
                            if create_report() is True:
                                bt_sig_test = BluetoothSignaling(ip_addr)
                                bt_sig_test.Set_State('ON')
                                bt_sig_test.Set_ExpectedPower(20)
                                print('Trying to connect a bt eut.........')
                                connect_bt_eut()
                                """bt test"""
                                bt_test(measurement_type=measurement_selection, channel_type=channel_selection)
                            else:
                                print('\nFailed to create report, back to channel menu\n')
                                continue
                        elif channel_selection.upper() == 'B':
                            print('\nBack to main menu')
                            break
                        elif channel_selection.upper() == 'E':
                            print("******************************************************************\n")
                            print('Exit the program, have a good day!!!')
                            time.sleep(5.0)
                            sys.exit('See you ^_^')
                        else:
                            print('\nInvalid input, try again O_O !!!')
                            continue
                else:
                    print('\nInvalid input, try again O_O !!!')
                    continue
        except Exception as e:
            print(e)
            time.sleep(5.0)


