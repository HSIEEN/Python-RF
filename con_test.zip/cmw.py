import time

from rssd.RCT.Common import RCT
from time import sleep

bt_sig_conf = 'CONFigure:BLUetooth:Signaling1'
bt_sig_rout = 'Route:BLUetooth:Signaling1'


class WifiSignaling(RCT):
    frequency_band = 'B24GHz'
    standard = 'BSTD'
    input_standard = 'DSSS'
    modulation_coding_rate = "C11MBits"

    def __init__(self, ip_addr):
        super(RCT, self).__init__()
        self.jav_Open(ip_addr)
        print(f"The connected instrument information: {self.query("*IDN?")}")
        self.write("*RST")
        while self.query("*OPC?") != '1':
            time.sleep(0.5)
        self.Preset()

    """*********************Basic settings*****************************"""
    def Set_Source_state(self, state='ON'):
        self.write(f' SOURce:WLAN:SIGN:STATe {state}')
        while self.query("*OPC?") != '1':
            time.sleep(0.5)

    def Get_Source_state(self):
        return self.query('SOURce:WLAN:SIGN:STATe?')

    def Set_FrequencyBand(self, band='B24Ghz'):
        """

        :param band: 'B24Ghz' for 2.4GHz band; 'B5Ghz' for 5GHz band
        :return:
        """
        self.write(f'CONFigure:WLAN:MEAS:RFSettings:FREQuency:BAND {band}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.frequency_band = band

    def Set_Channel(self, ch='1'):
        """

        :param ch: channel number= 1 to 196
        :return:
        """
        self.write(f'CONF:WLAN:SIGN1:RFS:CHAN {ch}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_Standard(self, standard='BSTD'):
        """

        :param standard: 'BSTD' for 802.11b; 'ASTD' for 802.11a; 'GSTD' for 802.11g
        'NGFSTD' for 802.11n
        :return:
        """
        self.write(f'CONFigure:WLAN:SIGN:CONNection:STANdard {standard}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.standard = standard

    def Set_InputSignal_standard(self, standard='DSSS'):
        """

        :param standard: 'DSSS' for 802.11b/g; 'LOFDm' for 802.11a/g; 'HTOFdm' for 802.11n
        :return:
        """
        self.write(f'CONFigure:WLAN:MEAS:ISIGnal:STANdard {standard}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.input_standard = standard

    def Set_ChannelBandWidth(self, bandwidth='BW20'):
        """

        :param bandwidth: 'BW20' for 20MHz; 'BW40' for 40MHz; 'BW80' for 80MHz
        :return:
        """
        self.write(f'CONF:WLAN:SIGN1:RFS:OCW {bandwidth}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_InputSignal_bandWidth(self, bandwidth='BW20'):
        """

        :param bandwidth: BW20' for 20MHz; 'BW40' for 40MHz; 'BW80' for 80MHz
        :return:
        """
        self.write(f'CONF:WLAN:MEAS1:ISIG:BWID {bandwidth}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_Route(self, rx='RF1C', tx='RF1C'):
        """

        :param rx: RF1C or RF2C
        :param tx: RF1C or RF1O or RF2C
        :return:
        """
        self.write(f'ROUT:WLAN:SIGN1:SCEN:SCEL1:FLEX SUU1, {rx}, RX1, {tx}, TX1')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_ExternalAttenuation(self, rx_att=0, tx_att=0):
        """

        :param rx_att: -50 to 90
        :param tx_att: -50 to 90
        :return:
        """
        self.write(f'CONFigure:WLAN:SIGN:RFSettings:EATTenuation:INPut {rx_att}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write(f'CONFigure:WLAN:SIGN:RFSettings:EATTenuation:OUTPut {tx_att}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    # def Init_Connection_SupportedRates_DSSS_state(self):
    #
    #     self.write("CONFigure:WLAN:SIGN:CONNection:SRATes:DSSSconf DISabled,DISabled,DISab")
    #     while self.query("*OPC?") != '1':
    #         time.sleep(0.1)

    def Set_PacketGenerator(self):
        self.write('CONFigure:WLAN:SIGN:PGEN1:CONFig OFF,10,1000,PRANdom')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write('CONFigure:WLAN:SIGN:PGEN2:CONFig OFF,10,1000,PRANdom')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write('CONFigure:WLAN:SIGN:PGEN3:CONFig OFF,10,1000,PRANdom')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Get_PacketGenerator_status(self):
        return self.query(" CONFigure:WLAN:SIGN:PGEN:CONFig?")

    def Set_Expected_PeakEnvelopePower(self, power=-50):
        self.write(f"CONF:WLAN:SIGN1:RFS:EPEP {power}")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Preset(self):
        self.write('TRIG:WLAN:SIGN:RX:MACF:OFML DEFault')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'CONF:WLAN:SIGN:CONN:OMOD AP')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write("ROUTe:WLAN:MEAS:SCENario:CSPath 'WLAN Sig1'")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write('CONFigure:FDCorrection:DEACtivate:ALL')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write("TRIGger:WLAN:MEAS:MEValuation:SOURce 'Free Run'")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write("CONF:WLAN:SIGN:CONN:SSID 'COROS-WIFI-TEST'")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write("CONFigure:WLAN:SIGN:CONNection:SECurity:PASS DISabled")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f' CONF:WLAN:SIGN:PGEN:PROT ICMP')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'CONFigure:WLAN:MEAS:RFSettings:ENPower 25')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'CONFigure:WLAN:SIGN:RFSettings:EPEPower 25')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'CONFigure:WLAN:SIGN:RFSettings:BOPower -50')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'CONFigure:WLAN:MEAS:RFSettings:UMARgin 0')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'CONFigure:WLAN:MEAS:RFSettings:MLOFfset 0')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'TRIGger:WLAN:MEAS:MEValuation:THReshold -50')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'TRIGger:WLAN:MEAS:MEValuation:TOUT 3')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'TRIGger:WLAN:SIGN:TX:MACFrame:SLOPe REDGe')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'TRIGger:WLAN:SIGN:TX:MACFrame:PLENgth:MODE BLENgth')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'TRIGger:WLAN:SIGN:RX:MACFrame:SLOPe FEDGe')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write(f'TRIGger:BASE:EXTA:DIRection OUT')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write("TRIGger:BASE:EXTA:SOURce 'WLAN Sig1: FrameTrigger'")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write("TRIGger:BASE:EXTA:SLOPe REDGe")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write("CONFigure:WLAN:MEAS:MEValuation:TOUT 100")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write("CONFigure:WLAN:SIGN:CONNection:SRATes ENABle")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        self.write("CONFigure:WLAN:SIGN:CONNection:SRATes:DSSSconf DISabled,DISabled,DISabled, Disabled")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

        # self.write("CONFigure:WLAN:SIGN:CONNection:SRATes:OMCSconf NOTSupported,NOTSupport")
        # while self.query("*OPC?") != '1':
        #     time.sleep(0.1)

        # self.write("TRIGger:WLAN:SIGN1:RX:MACFrame:RREStriction OFF")
        # while self.query("*OPC?") != '1':
        #     time.sleep(0.1)
        self.write("CONFigure:WLAN:SIGN:CONNection:SRATes DISable")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Get_ConnectionStatus(self):
        return self.query("FETCH:WLAN:SIGN:PSWitched:STATe?")

    def Wait_ConnectionStatus_UntilAssociated(self):
        while self.Get_ConnectionStatus() != "ASS":
            time.sleep(0.1)
        return True

    def Set_ModulationFilter(self, mode="CCK11"):
        """
        :param mode: For OFDM: ALL|BPSK|QPSK|QAM16|QAM64|QAM256|QAM|1024; FOR DSSS:
        ALL|DBPSK|DQPSK|CCK5_5|CCK11
        :return:
        """
        self.write(f"CONF:WLAN:MEAS:ISIG:MODF {mode}")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    """************************Rx Settings*****************************"""
    def Set_Rx_TriggerMode(self, mode='DCBursts'):
        """

        :param mode: 'DCBursts' for DSSS/CCK Bursts; 'ALLBursts' for all bursts
        :return:
        """
        self.write(f' TRIGger:WLAN:SIGN1:RX:MACFrame:BTYPe {mode}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        # self.input_standard = standard

    def Set_Rx_TriggerBandwidth(self, bandwidth='BW20'):
        """

        :param bandwidth: 'BW20' for 20MHz; 'BW40' for 40MHz; 'BW80' for 80MHz
        :return:
        """
        self.write(f'TRIGger:WLAN:SIGN1:RX:MACFrame:BW {bandwidth}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_Trigger_RxMacFrame_bandwidth(self, bandwidth='BW20'):
        """

        :param bandwidth: BW20' for 20MHz; 'BW40' for 40MHz; 'BW80' for 80MHz
        :return:
        """
        self.write(f' TRIGger:WLAN:SIGN1:RX:MACFrame:BW {bandwidth}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    """****************************Tx Settings****************************"""
    def Set_Tx_BurstPower(self, power=-50):
        self.write(f"CONFigure:WLAN:SIGNaling1:RFSettings:BOPower {power}")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
    """*************************PER Settings**********************************"""
    def Set_PER_ModulationCodeRate(self, rate='C11Mbits'):
        """

        :param rate: BR12|QR12|QR34|....|C55Mbits|C11Mbits|MCS8|MCS9...|MCS15
        :return:
        """
        self.write(f"CONFigure:WLAN:SIGN:PER:MCRate {rate}")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.modulation_coding_rate = rate

    def Abort_PER(self):
        self.write('ABOR:WLAN:SIGN1:PER')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_PER(self):

        format_table = {"BSTD": {"frame_format": "NHT", "modulation_coding_rate": "C11Mbits"},
                         "GSTD": {"frame_format": "NHT", "modulation_coding_rate": "Q6M34"},
                         "NGFSTD": {"frame_format": "HTG", "modulation_coding_rate": "MCS7"}}
        self.write(f'CONFigure:WLAN:SIGN:PER:FDEF {format_table[self.standard]["frame_format"]},BW20,'
                   f'{format_table[self.standard]["modulation_coding_rate"]},LONG')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.modulation_coding_rate = format_table[self.standard]["modulation_coding_rate"]
        self.write("CONFigure:WLAN:SIGN:PER:PAYL:SIZE 500")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:SIGN:PER:DINTerval 1")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:SIGN:PER:DPAT PRAN")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        # self.write("CONFigure:WLAN:SIGN:PER:DFRame:HEMU:USER:CTYPe BCC")
        # while self.query("*OPC?") != '1':
        #     time.sleep(0.1)
        self.write("CONFigure:WLAN:SIGN:PER:LIMit 50")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:SIGN:PER:PACKets 1000")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Get_PER_Results(self):
        self.Abort_PER()
        data = self.query("READ:WLAN:SIGNaling1:PER?").split(',')
        return round(float(data[1]), 2), round(float(data[4]), 2)

    def Init_PER_Test(self):
        self.write("INIT:WLAN:SIGN:PER")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Get_PER_state(self):
        return self.query("FETCh:WLAN:SIGN:PER:STATe?")

    def Wait_PER_UntilReady(self):

        while self.Get_PER_state() != 'RDY':
            time.sleep(0.1)

    """**********************MultiEvaluation Settings*****************************"""
    def Abort_MEV(self):
        self.write('ABOR:WLAN:MEAS1:MEV')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_MultiEvaluation(self):
        self.write("TRIGger:WLAN:SIGN1:RX:MACFrame:RREStriction OFF")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:REPetition SINGleshot")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:RESult ON,OFF,OFF,OFF,OFF,OFF,OFF,OFF")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:SCOunt:PVTime 10")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:PVTime:ALENgth 199")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:PVTime:RPOWer MEAN")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:SCOunt:TSMask 1")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:SCOunt:MODulation 1")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:COMPensation:TRACKing:PHASe ON")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:COMPensation:TRACKing:TIMing ON")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.write("CONFigure:WLAN:MEAS:MEValuation:COMPensation:TRACKing:LEVel ON")

    def Close(self):
        self.jav_Close()


class BluetoothSignaling(RCT):
    burst_type = "BR"
    packet_type = 'DH1'
    pattern_type = 'PRBS9'
    test_mode = "loopback"
    tx_channel = 0
    rx_channel = 0
    tx_route = 'RF1C'
    rx_route = 'RF1C'
    tx_attenuation = 0.0
    rx_attenuation = 0.0
    tx_level = -80

    def __init__(self, ip_addr):
        super(RCT, self).__init__()
        self.jav_Open(ip_addr)
        print(f"The connected instrument information: {self.query("*IDN?")}")
        self.write("*RST")
        self.Set_Hopping('OFF')
        self.Set_White('OFF')
        self.write('CONF:BLU:SIGN1:RFS:ARAN OFF')
        self.write('CONF:BLU:SIGN1:RXQ:TOUT 30')
        self.write('CONF:BLU:SIGN1:RFS:UMAR 0')
        self.write('ROUTe:BLUetooth:MEASurement1:SCENario:CSPath keep')
        self.Set_OperationMode()
        # self.Set_Standards()
        self.Set_TestMode()
        self.Set_Route()
        self.Set_ExtAttenuation()
        self.Set_Trigger()

    def Set_TestMode(self, test_mode='loopback'):
        self.write(f'{bt_sig_conf}:TMODe {test_mode}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.test_mode = test_mode

    def Set_OperationMode(self, mode="RFtest"):
        """
        :param mode: 'RFtest', 'ECMode', 'PROFiles' or 'CNTest'
        :return:
        """
        self.write(f'{bt_sig_conf}:OPMode {mode}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Get_OperationMode(self):
        return self.write(f'{bt_sig_conf}:OPMode?')

    def Set_Route(self, rx_route='RF1C', tx_route='RF1C'):

        self.write(f"{bt_sig_rout}:SCEN:OTRX:FLEX SUU1, {rx_route}, RX1, {tx_route}, TX1")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.rx_route = rx_route
        self.tx_route = tx_route

    def Set_ExtAttenuation(self, tx_att=0.0, rx_att=0.0):

        self.write(f'{bt_sig_conf}:RFS:EATT:INP {rx_att}')
        self.write(f'{bt_sig_conf}:RFS:EATT:OUTP {tx_att}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.tx_attenuation = tx_att
        self.rx_attenuation = rx_att

    def Set_Trigger(self):
        self.write("TRIGger:BASE:EXTA:DIRection OUT; :TRIGger:BASE:EXTB:DIRection OUT")
        self.write("TRIGger:BASE:EXTA:SOURce 'Bluetooth Sig1: SignallingTrigger';"
                   " :TRIGger:BASE:EXTB:SOURce 'Bluetooth Sig1: SignallingTrigger' ")
        self.write("TRIGger:BASE:EXTA:SLOPe FEDGe;:TRIGger:BASE:EXTB:SLOPe FEDGe")
        self.write("TRIGger:BASE:EXTA:SLOPe FEDGe;:TRIGger:BASE:EXTB:SLOPe FEDGe")
        self.write('CONF:BLU:MEAS1:MEV:REP SING')
        self.write('CONFigure:BLUetooth:SIGNaling1:RXQuality:REPetition SING')

    def Set_Hopping(self, state='OFF'):
        """
        :param state: 'On' or 'OFF'
        :return:
        """
        self.write(f"{bt_sig_conf}:RFS:HOPP {state}")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_White(self, state='OFF'):
        self.write(f"{bt_sig_conf}:Conn:Whit {state}")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_Connection_PowerControl(self, action="Max"):
        """
        :param action:  "UP" or "Down" or "Max"
        :return:
        """
        self.write(f'CONFigure:BLUetooth:SIGNaling1:CONNection:PCONtrol:STEP:ACTion {action}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_ExpectedPower(self, power=25):
        self.write(f'{bt_sig_conf}:RFS:ENP {power}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_BurstType(self, bt='BR'):
        """
        :param bt: BR or EDR
        :return:
        """
        self.write(f"{bt_sig_conf}:CONNection:BtyPe {bt}")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.burst_type = bt

    def Get_BurtType(self):
        return self.query(f"{bt_sig_conf}:CONNection:BTYpe?")

    def Set_Channels(self, tx_ch=0, rx_ch=0):
        self.write(f"{bt_sig_conf}:RFS:Channel:Loopback {tx_ch}, {rx_ch}")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.tx_channel = tx_ch
        self.rx_channel = rx_ch

    def Set_PatternType(self, pt='PRBS9'):
        """
        :param pt: 'P11' for 10101010; 'P44' for 11110000
        :return:
        """
        self.write(f'{bt_sig_conf}:CONN:PACK:PATT:{self.burst_type}ate {pt}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.pattern_type = pt

    def Set_PacketType(self, pt='DH1'):
        """

        :param pt: 'DH1','DH3', 'DH5' for BR; 'E21P', 'E23P', 'E25P',
         'E31P', 'E33P', 'E35P'
        :return:
        """
        self.write(f'{bt_sig_conf}:CONN:PACK:PTYP:{self.burst_type}ate {pt}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.packet_type = pt

    def Set_State(self, state="ON"):
        """
        :param state: 'ON' or 'OFF'
        :return:
        """
        self.write(f'SOUR:BLU:SIGN1:STAT {state}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Get_State(self):
        return self.query('SOUR:BLU:SIGN1:STAT?')

    def Set_Tx_level(self, txp=-80):
        self.write(f'{bt_sig_conf}:RFS:LEV {txp}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)
        self.tx_level = txp

    def Set_Connection_Action(self, action):
        """
        :param action: 'INQ' for searching EUT; 'SINQ' for stop searching EUT
        :return:
        """
        self.write(f'CALL:BLU:SIGN1:CONN:ACT {action}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Get_EUT(self):
        """
        :return: return a list about blu sign inquire results
        """
        inquire_times = 0
        while True:
            inquire_times = inquire_times + 1
            self.Set_Connection_Action("INQ")
            sleep(5)
            self.Set_Connection_Action("SINQ")
            sleep(1)
            eut_list = self.query(f'{bt_sig_conf}:CONN:INQ:PTAR:CAT?').split(',')
            if eut_list[0] != '0':
                return eut_list[4]
            elif inquire_times > 6:
                return None

    def Set_PageTarget(self, device_number=1):
        self.write(f'{bt_sig_conf}:CONN:PAG:PTAR {device_number}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    # def Set_TestModeConnection(self):
    #     pass

    def Set_TestMode_state(self, state='TMC'):
        """

        :param state: "TMConnect" or "DETach"
        :return:
        """

        self.write(f'CALL:BLU:SIGN1:CONN:ACT {state}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_PacketNumber(self, number):
        """
        :param number: 200, 500, 1000
        :return:
        """
        self.write(f'CONF:BLU:SIGN1:RXQ:PACK {number}')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Get_Connection_State(self):
        return self.query('FETC:BLU:SIGN1:CONN:STAT?')

    def Set_MEvaluation_PowerScalar_state(self, state):
        self.write(f"CONFigure:BLUetooth:MEASurement1:MEValuation:RESult:PSCalar {state}")
        self.write(f'CONFigure:BLUetooth:MEASurement1:MEValuation:SCOunt:PVTime 10')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_MEvaluation_ModulationScalar_state(self, state):
        self.write(f"CONFigure:BLUetooth:MEASurement1:MEValuation:RESult:MSCalar {state}")
        self.write(f'CONFigure:BLUetooth:MEASurement1:MEValuation:SCOunt:MODulation 10')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_MEvaluation_FrequencyDeviation_state(self, state):
        self.write(f"CONFigure:BLUetooth:MEASurement1:MEValuation:RESult:FDeviation {state}")
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Set_MEvaluation_All_Off(self):
        self.write('CONF:BLU:MEAS1:MEV:RES OFF,OFF,OFF,OFF,OFF,OFF,OFF,OFF,OFF,OFF,OFF,OFF,OFF')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Init_MEvaluation(self):

        self.write('INITiate:BLUetooth:MEASurement1:MEValuation')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Init_RxQuality(self):

        self.write('INITiate:BLUetooth:SIGNaling1:RXQuality:BER:BEDR')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Get_MEvaluation_state(self):
        return self.query('FETCh:BLUetooth:MEASurement1:MEValuation:STATe:ALL?')

    def Get_RxQuality_state(self):
        return self.query('FETCh:BLUetooth:SIGNaling1:RXQuality:BER:STATe:ALL:BEDR?')

    def Abort_RxQuality(self):
        self.write('ABORt:BLUetooth:SIGNaling1:RXQuality:BER')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Abort_MEvaluation(self):
        self.write('ABORt:BLUetooth:MEASurement1:MEValuation')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Stop_RxQuality(self):
        self.write('Stop:BLUetooth:MEASurement1:MEValuation')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Stop_MEvaluation(self):
        self.write('Stop:BLUetooth:MEASurement1:MEValuation')
        while self.query("*OPC?") != '1':
            time.sleep(0.1)

    def Read_MEvaluation_PowerScalar(self, data_type="AVER"):
        """
        :param data_type: 'AVER' or 'CURR' or 'MAX' or 'MIN'
        :return: formated data
        """
        data = self.query(f'Read:Bluetooth:Measurement1:MEvaluation:PVTime:{self.burst_type}ate:{data_type}?')
        if self.burst_type == 'BR':
            data = data.split(',')[2:6]
        elif self.burst_type == 'EDR':
            data = data.split(',')[2:7]
        elif self.burst_type == 'LE':
            data = data.split(',')[2:6]
        else:
            print('burst_type is invalid!')
            data = None
        data = [round(float(i), 2) for i in data]
        return data

    def Read_MEvaluation_ModulationScalar(self, data_type='AVER'):
        data = self.query(f'Read:Bluetooth:Measurement1:MEvaluation:MODulation:'
                          f'{self.burst_type}ate:{data_type}?').split(',')
        if self.burst_type == 'BR':
            if self.pattern_type == 'P11':
                data = data[3:6]+data[9:12]+[data[2]]
            elif self.pattern_type == 'P44':
                data = [data[3]] + data[6:9]
            elif self.pattern_type == 'PRBS9':
                data = [data[3]]
            else:
                print('Invalid pattern_type!')
            data = [round(float(i) / 1e3, 2) for i in data]
        elif self.burst_type == 'EDR':
            data = data[2:8]
            data = [round(float(i) / 1e3, 2) for i in data[0: 3]] + [round(float(i), 3) for i in data[3: 6]]
        elif self.burst_type == 'LE':
            pass
        else:
            print('invalid burst_type!')
        return data

    def Fetch_RxQuality_BER(self):
        return self.query('FETCh:BLUetooth:SIGNaling1:RXQuality:BER?')

    def Read_RxQuality_BER(self):
        return self.query('READ:BLU:SIGN1:RXQ:BER?')

    def Close(self):
        self.jav_Close()
