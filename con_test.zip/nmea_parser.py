import time
from datetime import datetime
import timeit
import serial
import numpy as np
from rich.console import Console
from rich import print as rprint
from rich.progress import track
console = Console()

time_interval = 3  # 10 seconds
port = "COM3"
baud_rate = 921600
prn_cn0_l1 = {}
prn_cn0_l5 = {}
sv_num_l1 = 0
sv_num_l5 = 0


def parse_init():
    global prn_cn0_l5, prn_cn0_l1, sv_num_l5, sv_num_l1
    prn_cn0_l1 = {}
    prn_cn0_l5 = {}
    sv_num_l1 = 0
    sv_num_l5 = 0


def parse_nmea_sentences(ser):
    """

    :param ser:
    :return: l1 SV number, mean of l1 sv cn value, l5 SV number, mean of l5 sv cn value
    """
    parse_init()
    # sentence_number = 0
    # sentence_order = 0
    # sentences_list = {}
    start = timeit.default_timer()
    interval = 0
    l1_cn_avg = 0
    l5_cn_avg = 0
    # sentences_list[l1_l5] = [i for i in range(1, sentence_number+1)]
    while interval <= time_interval or (sv_num_l1 < 1 and sv_num_l5 < 1):
        _, _, _, _ = parse_nmea_single_sentence(ser)
        stop = timeit.default_timer()
        interval = stop-start
        if interval > 15:
            break
    l1_cn_list = [i for i in prn_cn0_l1.values()]
    l5_cn_list = [i for i in prn_cn0_l5.values()]
    if len(l1_cn_list) > 0:
        l1_cn_avg = round(float(np.mean(l1_cn_list)), 2)
    if len(l5_cn_list) > 0:
        l5_cn_avg = round(float(np.mean(l5_cn_list)), 2)
    if interval > 20:
        return sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg
    return sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg


def parse_nmea_single_sentence(ser):
    """

    :param ser: serial port with pyserial
    :return: sentence_number, sentence_order, gps_band, sat_number
    """
    # start = timeit.default_timer()
    # interval = 0
    global sv_num_l5, sv_num_l1, prn_cn0_l5, prn_cn0_l1
    sentence_number, sentence_order, gps_band, sat_number = 0, 0, 0, 0
    block_start_flag_count = 0
    while block_start_flag_count < 2:
        # ser.reset_input_buffer()
        s = ser.readline().decode('windows-1252', 'ignore').strip()
        if s.startswith('$GNGGA') or s.startswith('$GNGNS'):
            block_start_flag_count = block_start_flag_count + 1
        if s.startswith('$GPGSV'):
            s = s.split(',')
            if len(s) < 4:
                block_start_flag_count = 0
                continue
            """Estimate gps band"""
            # s[-1] = s[-1].split('*')[0]
            gps_band = s[-1].split("*")[0]
            """record gps satellites number"""
            sat_number = int(s[3])
            sentence_number = int(s[1])
            sentence_order = int(s[2])
            """The first nmea sentence"""
            # if sentence_order == 1:
            # for i in range(1, sentence_number):
            for i in range(7, len(s), 4):
                if s[i].isdigit() and s[i - 3].isdigit():
                    if gps_band == '1':
                        # sv_num_l1 = sat_number
                        if prn_cn0_l1.get(s[i - 3]) is None:  # new satellite
                            prn_cn0_l1[s[i - 3]] = int(s[i])
                            sv_num_l1 = sv_num_l1 + 1
                    else:
                        # sv_num_l1 = sat_number
                        if prn_cn0_l5.get(s[i - 3]) is None:  # new satellite
                            prn_cn0_l5[s[i - 3]] = int(s[i])
                            sv_num_l5 = sv_num_l5 + 1
    return sentence_number, sentence_order, gps_band, sat_number
    # else:
        # return sentence_number, sentence_order, gps_band, sat_number
        # stop = timeit.default_timer()
        # interval = stop-start


def get_gnss_fix_status(ser, trial_times=1, trial_interval=10, percentage=1):
    """

    :param ser: a serial port
    :param trial_times:  test how many times
    :param trial_interval: test how long per time
    :param percentage:
    :return:
    """

    for times in range(trial_times):
        rprint(f"[green]***get_gnss_fix_status: trial_times={times+1}*****************")
        not_fix_times = 0
        for i in range(trial_interval):
            while True:
                # ser.reset_input_buffer()
                s = ser.readline().decode('windows-1252', 'ignore').strip()
                #
                # time.sleep(0.5)
                # s = ser.readline().decode('utf-8').strip()
                if s.startswith('$GNGGA') or s.startswith('$GNGNS'):
                    #
                    s = s.split(',')
                    if s[6] == '0' or s[6].startswith("N"):
                        console.log(f"***get_gnss_fix_status: [red] not fixed!!")
                        # print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                        not_fix_times = not_fix_times + 1
                        break
                    else:
                        console.log(f"***get_gnss_fix_status: [green] fixed!!")
                        break

        if not_fix_times/trial_times <= (1-percentage):
            return 1
    return 0
# if __name__ == "__main__":
#     ser = serial.Serial(port=port, baudrate=baud_rate)
#     mean_l1_cn, mean_l5_cn = parse_nmea_sentences(ser)
#     ser.close()
#     pass
