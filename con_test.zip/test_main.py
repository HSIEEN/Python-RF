import timeit

import serial
from RsInstrument import *
import sys
import time
import os
import xlwings as xw
from datetime import datetime
import openpyxl
import pyvisa as visa
from nmea_parser import parse_nmea_sentences, get_gnss_fix_status
from smbv import GnssConduction
import numpy as np
from cmw import BluetoothSignaling, WifiSignaling
from collections import defaultdict
import pandas as pd
from openpyxl.utils import get_column_letter
import tkinter as tk
from tkinter import filedialog
import shutil
from rich.console import Console
from rich import print as rprint
console = Console()


log_file = ""
# sys.stdout = log_file


port = "COM3"
baud_rate = 921600
instr = ''
ser = None
bt_sig_test = None
wifi_sig_test = None
gnss_test = None
bt_power0 = -80
wifi_power0 = -60
bt_power_scalar = defaultdict(list)
bt_sensitivity = defaultdict(list)
bt_modulation = defaultdict(list)
wifi_power = defaultdict(list)
wifi_sensitivity = defaultdict(list)
bt_PacketType_BurstType = {
        'BR': ['DH1', 'DH3', 'DH5'],
        'EDR': ['E21P', 'E25P', 'E35P']
    }
bt_PacketTypes_for_print = {'DH1': 'DH1', 'DH3': 'DH3', 'DH5': 'DH5',
                          'E21P': '2-DH1', 'E25P': '2-DH5', 'E35P': '3-DH5'}
bt_pattern_sheet = {'PRBS9': ['Tx_power_PRBS9', 'Tx_modulation_PRBS9'],
                 'P11': ['Tx_power_10101010', 'Tx_modulation_10101010'],
                 'P44': ['Tx_power_11110000', 'Tx_modulation_11110000']}
bt_column_index_for_ChannelType = {1: 'F', 3: 'H', 79: 'CF'}
measure_bt_or_wifi = {'1': 'BT', '2': 'WIFI', '3': 'BT and WIFI'}
measure_tx_or_rx = {'1': 'Tx', '2': 'Rx', '3': 'Tx and Rx'}
bt_rf_file = 'BT_conduction_template.xlsx'
wifi_rf_file = 'WIFI_conduction_template.xlsx'
bt_column_num = 3
wifi_standard_table = {'1': 'BSTD', '2': 'GSTD', '3': 'NGFSTD'}
wifi_standard_table_for_print = {'1': '802.11b', '2': '802.11g', '3': '802.11n'}
wifi_standard_inverse_table = {'BSTD': 1, 'GSTD': 2, 'NGFSTD': 3}


def check_instrument_info():
    rprint("Please make sure IP address of your test instrument starts with [bold green]192.168.1.xxx!")
    rm = visa.ResourceManager("@py")
    ip_str = rm.list_resources()
    rprint(f'[blue]Available resources: {ip_str}')
    items_num = len(ip_str)
    ip_address = ip_str[items_num-1].split('::')[1]
    rprint(f'The IP address of the remote instrument is: [green] {ip_address}')
    # 连接到rmt_server
    # cmw = RsInstrument('TCPIP::192.168.1.110::hislip0', reset=False)
    rmt_server = rm.open_resource(rm.list_resources()[items_num-1])
    rmt_server.clear()
    rmt_server.timeout = 3000
    rmt_server.write('SYST:DISP:UPD ON')
    rmt_server.write("*RST")
    time.sleep(3)
    instrument_info = rmt_server.query("*IDN?")
    rmt_server.close()
    # print(f"The instrument is :{instrument_info}")
    if "CMW" in instrument_info:
        return "CMW500", ip_address
    elif "SMBV" in instrument_info:
        return "SMBV100B", ip_address


def serial_port_wait(interval, ser_port):
    """

    :param interval: duration to wait in seconds
    :param ser_port:  serial port with VISA protocol
    :return:
    """
    start = time.perf_counter()
    end = start
    while end-start < interval:
        if (end-start) % 5 < 1:
            print(f"*****************Please wait, {round(interval-(end-start), 1)} "
                  f"seconds left.......")
        ser_port.reset_input_buffer()
        time.sleep(1)
        # s = ser_port.readlines()
        # s = ser_port.readlines().decode('windows-1252').strip()
        # s = ser_port.readline().decode('windows-1252').strip()
        # print(s)
        end = time.perf_counter()
    print(f"***************{round(interval, 1)} seconds elapsed, test continues......")


def bt_get_modulation_by_channel(burst_type='BR', channel=0):
    bt_sig_test.Set_Channels(channel, 0)
    bt_sig_test.Set_BurstType(burst_type)
    bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
    bt_sig_test.Set_PacketType(bt_sig_test.packet_type)
    return bt_sig_test.Read_MEvaluation_ModulationScalar()


def bt_get_modulationScalar(channel='0'):
    """

    :param channel: 'all' for all ch; 'lmh' for low_mid_high ch; specific number for certain ch, like '0' for ch 0
    :return: a dict for Tx bt_modulation
    """
    if channel.isdigit():
        channel_range = [int(channel)]
    elif channel.upper() == 'LMH':
        channel_range = range(0, 79, 39)
    elif channel.upper() == 'ALL':
        channel_range = range(0, 79, 1)
    else:
        raise ValueError("Invalid mode or channel argument")

    for channel in channel_range:
        for burst_type, packet_types in bt_PacketType_BurstType.items():
            for packet_type in packet_types:
                bt_sig_test.Set_BurstType(burst_type)
                bt_sig_test.Set_PacketType(packet_type)
                bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
                ch_str = f'CH{channel}'
                bt_modulation[ch_str].extend(bt_get_modulation_by_channel(burst_type, channel))


def bt_get_powerScalar_by_channel(burst_type='BR', channel=0):
    bt_sig_test.Set_Channels(channel, 0)
    bt_sig_test.Set_BurstType(burst_type)
    bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
    bt_sig_test.Set_PacketType(bt_sig_test.packet_type)
    return bt_sig_test.Read_MEvaluation_PowerScalar()


def bt_get_powerScalar(channel='0'):
    """

    :param channel: 'all' for all ch; 'lmh' for low_mid_high ch; specific number for certain ch, like '0' for ch 0
    :return: a dict for Tx Power scalar
    """
    if channel.isdigit():
        channel_range = [int(channel)]
    elif channel.upper() == 'LMH':
        channel_range = range(0, 79, 39)
    elif channel.upper() == 'ALL':
        channel_range = range(0, 79, 1)
    else:
        raise ValueError("Invalid mode or channel argument")

    for channel in channel_range:
        for burst_type, packet_types in bt_PacketType_BurstType.items():
            for packet_type in packet_types:
                bt_sig_test.Set_BurstType(burst_type)
                bt_sig_test.Set_PacketType(packet_type)
                bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
                ch_str = f'CH{channel}'
                bt_power_scalar[ch_str].extend(bt_get_powerScalar_by_channel(burst_type, channel))


def bt_get_tx_results_by_channel(burst_type='BR', channel=0):
    bt_sig_test.Set_Channels(channel, 0)
    bt_sig_test.Set_BurstType(burst_type)
    bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
    bt_sig_test.Set_PacketType(bt_sig_test.packet_type)
    return bt_sig_test.Read_MEvaluation_PowerScalar(), bt_sig_test.Read_MEvaluation_ModulationScalar()


def bt_get_tx_results(channel='0'):
    global bt_column_num
    if channel.isdigit():
        channel_range = [int(channel)]
        bt_column_num = 1
    elif channel.upper() == 'LMH':
        channel_range = range(0, 79, 39)
        bt_column_num = 3
    elif channel.upper() == 'ALL':
        channel_range = range(0, 79, 1)
        bt_column_num = 79
    else:
        raise ValueError("Invalid mode or channel argument")
    # 由于直接测量完BR后直接测量EDR会导致EDR数据偏高，需要在BR模式数据测量完毕后，关闭bt_signal后再打开，才能测量EDR
    for burst_type, packet_types in bt_PacketType_BurstType.items():
        for channel in channel_range:
            print(
                f"\n>>>>>>>>>>>>>>>>>>Channel {channel} test begins at {datetime.now().now()}<<<<<<<<<<<<<<<<")
            print(f"\n.................................Burst type {burst_type} "
                  f"is under test...................................")
            for packet_type in packet_types:
                bt_sig_test.Set_BurstType(burst_type)
                bt_sig_test.Set_PacketType(packet_type)
                print(f"********************************Packet type {bt_PacketTypes_for_print[packet_type]} "
                      f"is under test**********************************")
                bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
                ch_str = f'CH{channel}'
                power_data, bt_modulation_data = bt_get_tx_results_by_channel(burst_type, channel)
                bt_power_scalar[ch_str].extend(power_data)
                bt_modulation[ch_str].extend(bt_modulation_data)
        bt_sig_test.Set_TestMode_state(state='DET')
        bt_sig_test.Set_TestMode_state(state='TMC')

    # for channel in channel_range:
    #     print(f"\n>>>>>>>>>>>>>>>>>>Channel {channel} test begins at begins at {datetime.now().now()}<<<<<<<<<<<<<<<<")
    #     for burst_type, packet_types in bt_PacketType_BurstType.items():
    #         print(f"\n.................................Burst type {burst_type} "
    #               f"is under test...................................")
    #         for packet_type in packet_types:
    #             bt_sig_test.Set_BurstType(burst_type)
    #             bt_sig_test.Set_PacketType(packet_type)
    #             print(f"********************************Packet type {bt_PacketTypes_for_print[packet_type]} "
    #                   f"is under test**********************************")
    #             bt_sig_test.Set_PatternType(bt_sig_test.pattern_type)
    #             ch_str = f'CH{channel}'
    #             power_data, bt_modulation_data = bt_get_tx_results_by_channel(burst_type, channel)
    #             bt_power_scalar[ch_str].extend(power_data)
    #             bt_modulation[ch_str].extend(bt_modulation_data)


def bt_get_sensitivity(channel='0'):
    """

    :param channel: 'all' for all ch; 'lmh' for low_mid_high ch; specific number for certain ch, like '0' for ch 0
    :return: a dict for Rx bt_sensitivity
    """
    global bt_power0
    if channel.isdigit():
        channel_range = [int(channel)]
    elif channel.upper() == 'LMH':
        channel_range = range(0, 79, 39)
    elif channel.upper() == 'ALL':
        channel_range = range(0, 79, 1)
    else:
        raise ValueError("Invalid mode or channel argument")

    for burst_type, packet_types in bt_PacketType_BurstType.items():
        for channel in channel_range:
            bt_sig_test.Set_BurstType(burst_type)
            bt_sig_test.Set_PacketType(bt_PacketType_BurstType[burst_type][0])  # BR仅测量DH1，EDR仅测量2DH1
            bt_sig_test.Set_PatternType('PRBS9')
            ch_str = f'CH{channel}'
            bt_sensitivity[ch_str].append(bt_get_sensitivity_by_channel(burst_type, channel))
        if bt_sig_test.burst_type == 'BR':                    # 测量完BR后需要断开蓝牙信号发生器开关并重新连接蓝牙，否则测量出错
            bt_sig_test.Set_Channels(0, 0)
            bt_power0 = -80
            bt_sig_test.Set_State('OFF')
            time.sleep(2)
            bt_sig_test.Set_State('ON')
            bt_sig_test.Set_Tx_level(-40)                     # 连接蓝牙之前需重新设置TX_level为-40dBm，否则测量出错
            bt_connect_eut()


def bt_get_sensitivity_for_all_channels():
    for burst_type in ['BR', 'EDR']:
        for channel in range(0, 79):
            ch_str = 'CH'+str(channel)
            if ch_str not in list(bt_sensitivity.keys()):
                bt_sensitivity[ch_str] = []
            bt_sensitivity[ch_str].append(bt_get_sensitivity_by_channel(burst_type, channel))


def bt_get_sensitivity_for_lmh_channels():
    # ch_list = [0, 39, 78]
    for burst_type in ['BR', 'EDR']:
        for channel in range(0, 79, 39):
            ch_str = 'CH' + str(channel)
            if ch_str not in list(bt_sensitivity.keys()):
                bt_sensitivity[ch_str] = []
            bt_sensitivity[ch_str].append(bt_get_sensitivity_by_channel(burst_type, channel))


def bt_get_sensitivity_for_specific_channel(channel):
    # ch_list = channel
    for burst_type in ['BR', 'EDR']:
        ch_str = 'CH' + str(channel)
        if ch_str not in list(bt_sensitivity.keys()):
            bt_sensitivity[ch_str] = []
        bt_sensitivity[ch_str].append(bt_get_sensitivity_by_channel(burst_type, channel))


def bt_get_sensitivity_by_channel(burst_type="BR", channel=0):
    global bt_power0
    power = bt_power0
    bt_sig_test.Set_Tx_level(power)
    bt_sig_test.Set_BurstType(burst_type)
    bt_sig_test.Set_PacketType(bt_PacketType_BurstType[burst_type][0])
    bt_sig_test.Set_PatternType('PRBS9')

    last_step = 3
    bt_sig_test.Set_Channels(0, channel)
    print(f"----Channel: {channel}, Mode: {burst_type} test begins at {datetime.now().now()}------")
    while True:
        print(f"***Set Tx_level: {round(power, 2)}dBm")
        bt_sig_test.Set_Tx_level(power)
        # time.sleep(2)
        cur_step, ber = bt_get_power_step()

        print(f"***Current ber is: {round(ber, 3)}%")
        print(f"***Power step: {-round(cur_step, 2)}dB\n")
        if -0.2 < last_step*cur_step < 0:
            if last_step > 0:
                bt_power0 = power+last_step
                # return bt_power0
            elif last_step < 0:
                bt_power0 = power
                # return bt_power0
            return bt_power0
        last_step = cur_step
        power = power - cur_step


def bt_get_power_step():

    if bt_sig_test.burst_type == 'BR':
        err = 0.1
    elif bt_sig_test.burst_type == 'EDR':
        err = 0.01
    elif bt_sig_test.burst_type == 'LE':
        err = 10
    else:
        err = 0
    """
    wait until the rx_quality state becomes "rdy", read 3 times when BER != 0.0
    """
    ber0 = bt_get_ber()
    """
    when ber == 0.0, set power step to be 3 db, the power should decrease by 3 db
    """
    if ber0 < 1e-6:
        return 3.0, ber0
    """
    when ber != 0.0, read 2 more times
    """
    ber1 = bt_get_ber()
    ber2 = bt_get_ber()

    ber = [ber0, ber1, ber2]
    ber_arr = np.array(ber)
    if np.all(ber_arr <= err/5):
        power_step = 1.0
    elif np.any(ber_arr > err/5) and np.all(ber_arr <= err/2):
        power_step = 0.5
    elif np.any(ber_arr > err/2) and np.all(ber_arr <= err):
        power_step = 0.2
    elif np.any(ber_arr > err) and np.all(ber_arr <= 2*err):
        power_step = -0.5
    elif np.any(ber_arr >= 2*err):
        power_step = -1.0
    else:
        power_step = None
    return power_step, max(ber)


def bt_get_ber():
    ber_result = bt_sig_test.Read_RxQuality_BER().split(',')
    ber = float(ber_result[1])
    return ber


def bt_rx_test(channel='all'):
    # print('Trying to connect a bt eut.........')
    # bt_connect_eut()
    print(f"--------------------BT_Rx test begins at {datetime.now().now()}--------------------")
    bt_sig_test.Set_PatternType('PRBS9')
    bt_get_sensitivity(channel)
    print(bt_sensitivity)
    df_sens = pd.DataFrame.from_dict(bt_sensitivity)
    with pd.ExcelWriter(bt_rf_file, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
        df_sens.to_excel(writer, sheet_name='Rx_sensitivity', startrow=0, startcol=2, index=False)


def bt_tx_test(channel_type='all'):
    bt_sig_test.Set_MEvaluation_All_Off()
    bt_sig_test.Set_MEvaluation_FrequencyDeviation_state('ON')
    bt_sig_test.Set_MEvaluation_PowerScalar_state('ON')
    bt_sig_test.Set_MEvaluation_ModulationScalar_state('ON')
    print(f"--------------------BT_Tx test is in progress begins at {datetime.now().now()}------------------")
    global bt_power_scalar, bt_modulation
    for pt, sheet_list in bt_pattern_sheet.items():
        print(f"\n~~~~~~~~~~~~~~~~~~~~Pattern type {pt} test begins at {datetime.now().now()}~~~~~~~~~~~~~~~")
        df_measurements = []
        bt_sig_test.Set_PatternType(pt)
        bt_get_tx_results(channel_type)
        df_bt_power = pd.DataFrame.from_dict(bt_power_scalar)
        df_bt_power.insert(loc=0, column='Average', value=df_bt_power.mean(axis=1))
        df_bt_modulation = pd.DataFrame.from_dict(bt_modulation)
        df_bt_modulation.insert(loc=0, column='Average', value=df_bt_modulation.mean(axis=1))
        df_measurements.append(df_bt_power)
        df_measurements.append(df_bt_modulation)

        with pd.ExcelWriter(bt_rf_file, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
            # df_power.to_excel(writer, sheet_name=sheet, startrow=0, startcol=4, index=False)
            for i in range(2):
                df_measurements[i].to_excel(writer, sheet_name=sheet_list[i], startrow=0, startcol=4, index=False)
        bt_power_scalar = defaultdict(list)
        bt_modulation = defaultdict(list)
    # bt_sig_test.Close()
    """Formatting tx and rx data"""
    wb = xw.Book(bt_rf_file)
    for sheet in wb.sheet_names:
        ws = wb.sheets[sheet]
        ws.range('E2:CE40').number_format = '0.000'
        ws.range('A1:CE40').api.HorizontalAlignment = -4108
        ws.range('A1:CE40').columns.autofit()
        ws.range('E1:E40').api.Font.Bold = True
        row_num = ws.range('F1').current_region.last_cell.row - 1
        if bt_column_num == 1:
            continue
        for i in range(1, row_num + 1):
            row_data = ws.range(f'F{i + 1}:{bt_column_index_for_ChannelType[bt_column_num]}{i + 1}').value
            max_column_letter = get_column_letter(row_data.index(max(row_data)) + 6)
            min_column_letter = get_column_letter(row_data.index(min(row_data)) + 6)
            ws.range(f'{max_column_letter}{i + 1}').color = (255, 255, 0)
            ws.range(f'{max_column_letter}{i + 1}').api.Font.Bold = True
            ws.range(f'{min_column_letter}{i + 1}').color = (0, 255, 0)
            ws.range(f'{min_column_letter}{i + 1}').api.Font.Bold = True
    wb.save()
    wb.close()
    xw.App().quit()


def bt_test(measurement_type='1', channel_type='all'):
    measurement_actions = {
        '1': lambda: bt_tx_test(channel_type),
        '2': lambda: bt_rx_test(channel_type),
        '3': lambda: (bt_tx_test(channel_type), bt_rx_test(channel_type))
    }

    try:
        measurement_actions[measurement_type]()
    except KeyError:
        raise ValueError(f'Invalid measurement type: {measurement_type}')


def bt_connect_eut():
    eut_state = bt_sig_test.Get_EUT()
    if not eut_state:
        print('Time out, please check the state of your device')
    else:
        print(f'Eut BTAddress is: {eut_state}')
        bt_sig_test.Set_PageTarget()
        # bt_sig_test.Set_TestMode()
        bt_sig_test.Set_TestMode_state()
        while bt_sig_test.Get_Connection_State() != 'TCON':
            print(bt_sig_test.Get_Connection_State(), end=',')
            time.sleep(1)
            print(bt_sig_test.Get_Connection_State(), end=',')
    print('')


def bt_create_report():
    global bt_rf_file
    # src_file0 = '//nas.local/DATA/Wireless/AntennaTest/Templates/Latest/RF_conduction_template.xlsx'
    src_file0 = 'D:/Templates/BT_conduction_template.xlsx'
    # src_file1 = '//10.0.0.5/DATA/Wireless/AntennaTest/Templates/Latest/RF_conduction_template.xlsx'
    src_file1 = 'D:/Templates/BT_conduction_template.xlsx'
    print("*******************************************************************\n")
    print("========Formatting and writing test results to an xlsx file========\n")
    print('*******Please select a directory to store your test reports********\n')
    time.sleep(1.0)
    source_file_path = filedialog.askdirectory(title='Select storage directory')
    if source_file_path == '':
        print('No directory selected, please choose one. Cancelling the selection, '
              'you will go back to the channel menu')
        source_file_path = filedialog.askdirectory(title='Select storage directory')
    if source_file_path == '':
        return False
    print(f"The report file directory is {source_file_path}\n")
    excel_name = input("========Please enter the report name (35 characters or less)========\n")
    if excel_name == '':
        print('Name is missing, please type the report file name again. '
              'Wrong input returns to channel menu\n')
        excel_name = input("========Please enter the report name========\n")
    if len(excel_name) > 35:
        print('Name too long, must be under 35 characters. '
              'Wrong input returns to channel menu\n')
        excel_name = input("========Please enter the report name========\n")
    if '.' in excel_name:
        print('Name has a ".", please retype the report name. '
              'Wrong input returns to channel menu\n')
        excel_name = input("========Please enter the report name========\n")
    if excel_name == '' or len(excel_name) > 35 or '.' in excel_name:
        return False
    target_file = f'{source_file_path}/{excel_name}.xlsx'
    bt_rf_file = target_file
    # if the file has existed, delete the file
    if os.path.exists(target_file):
        print('File already exists. It will be replaced with test data. Yes(y) or No(n)')
        if_delete = input()
        if if_delete == 'n':
            return False
        os.remove(target_file)
    try:
        shutil.copyfile(src_file0, target_file)
    except:
        shutil.copyfile(src_file1, target_file)
    time.sleep(0.5)
    return True


def wifi_create_report():
    global wifi_rf_file
    # src_file0 = '//nas.local/DATA/Wireless/AntennaTest/Templates/Latest/RF_conduction_template.xlsx'
    src_file0 = 'D:/Templates/WIFI_conduction_template.xlsx'
    # src_file1 = '//10.0.0.5/DATA/Wireless/AntennaTest/Templates/Latest/RF_conduction_template.xlsx'
    src_file1 = 'D:/Templates/WIFI_conduction_template.xlsx'
    print("*******************************************************************\n")
    print("========Formatting and writing test results to an xlsx file========\n")
    print('*******Please select a directory to store your test reports********\n')
    time.sleep(1.0)
    source_file_path = filedialog.askdirectory(title='Select storage directory')
    if source_file_path == '':
        print('No directory selected, please choose one. Cancelling the selection, '
              'you will go back to the channel menu')
        source_file_path = filedialog.askdirectory(title='Select storage directory')
    if source_file_path == '':
        return False
    print(f"The report file directory is {source_file_path}\n")
    excel_name = input("========Please enter the report name (35 characters or less)========\n")
    if excel_name == '':
        print('Name is missing, please type the report file name again. '
              'Wrong input returns to channel menu\n')
        excel_name = input("========Please enter the report name========\n")
    if len(excel_name) > 35:
        print('Name too long, must be under 35 characters. '
              'Wrong input returns to channel menu\n')
        excel_name = input("========Please enter the report name========\n")
    if '.' in excel_name:
        print('Name has a ".", please retype the report name. '
              'Wrong input returns to channel menu\n')
        excel_name = input("========Please enter the report name========\n")
    if excel_name == '' or len(excel_name) > 35 or '.' in excel_name:
        return False
    target_file = f'{source_file_path}/{excel_name}.xlsx'
    wifi_rf_file = target_file
    # if the file has existed, delete the file
    if os.path.exists(target_file):
        print('File already exists. It will be replaced with test data. Yes(y) or No(n)')
        if_delete = input()
        if if_delete == 'n':
            return False
        os.remove(target_file)
    try:
        shutil.copyfile(src_file0, target_file)
    except:
        shutil.copyfile(src_file1, target_file)
    time.sleep(0.5)
    return True


"""
global variables for GNSS test
"""

attenuation = 30
time_schedule = [780, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60,
                 60, 60, 60, 60, 60, 60, 60, 60]

# time_schedule = [120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120,
#                       120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120]
power_table = [-130, -135, -140, -145, -150, -155, -160]


def gps_get_ttff(start_mode='cold', power=-130):
    """

    :param start_mode: 'hot' or 'cold'
    :param power: -145 -- -110
    :return:
    """
    global gnss_test
    """Initiate smbv100b and set dual-band mode"""

    """In warm start test, positioning for 13 minutes is a must"""
    # ser = serial.Serial(port=port, baudrate=baud_rate)
    if start_mode != 'cold':
        gnss_test.Set_Power(int(-130 + attenuation))
        ser.write(b'$PAIR006*3C\r\n')
        print(
            f"\n*********Set gps power {float(gnss_test.Get_Power()) - attenuation}dBm and wait"
            f" 780 secs............")
        time.sleep(10)
        # time.sleep(780)
    ttff_all = []
    ttff = 0
    gnss_test.Set_Power(power+attenuation)
    for i in range(20):
        print(f"-----------test loop {i+1}--------------")
        print(f"********{start_mode} start the gnss chip")
        if start_mode == 'cold':
            ser.write(b'$PAIR006*3C\r\n')
        elif start_mode == 'hot':
            ser.write(b'$PAIR004*3E\r\n')
        start = timeit.default_timer()
        ser.reset_input_buffer()
        while not get_gnss_fix_status(ser, trial_times=1):
            print('************GNSS status: Not fixed!')
        print('************GNSS status: Fixed!')
        stop = timeit.default_timer()
        ttff_single = stop-start
        ttff_all.append(ttff_single)
        ttff = ttff+ttff_single
        print(f"*********ttff at test loop_{i} at {start_mode} start is {round(ttff_single, 2)}s\n")
    print(f"############# The final ttff is: {round(ttff/20, 2)}s with power {power}dBm ################")
    return ttff/20


def gps_get_acquiring_sensitivity(start_mode='cold'):
    """
    :param: start_mode = 'hot','warm' or 'cold'
    :return: acquiring sensitivity at hot, warm or cold start
    """
    console.log(f"[black on red]------------------Test acquiring sensitivity at {start_mode}"
                f"start-------------------")
    print(f"------------------Test acquiring sensitivity at {start_mode} start-------------------", file=log_file)
    global gnss_test, ser
    # attenuation = 20
    # time_schedule = [80, 60, 60, 60, 60, 60, 60, 60, 60, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]
    acquiring_power_table_at_cold_start = [-150, -149, -148, -147.5, -147, -146.5,
                                           -146, -145.5, -145, -144.5, -144, -143.5, -143, -142.5, -142, -141.5]
    acquiring_power_table_at_cold_start = [i+attenuation for i in acquiring_power_table_at_cold_start]
    acquiring_power_table_at_warm_start = [i-5 for i in acquiring_power_table_at_cold_start]
    acquiring_power_table_at_hot_start = [i-15 for i in acquiring_power_table_at_cold_start]
    acquiring_power_table = {'cold': acquiring_power_table_at_cold_start, 'warm': acquiring_power_table_at_warm_start,
                             'hot': acquiring_power_table_at_hot_start}
    """Initiate smbv100b and set dual-band mode"""
    # gnss_test = GnssConduction(ip_addr)

    """In warm or hot start test, positioning for 13 minutes is a must"""
    step = 0
    gnss_test.Set_Power(acquiring_power_table[start_mode][step])
    rprint(f"\n[blue]*********Set gps power {float(gnss_test.Get_Power()) - attenuation}dBm............")

    if start_mode == 'cold':
        ser.write(b'$PAIR006*3C\r\n')
        print("***********cold start the chip to continue testing****************")
    elif start_mode == 'warm':
        ser.write(b'$PAIR005*3F\r\n')
        print("***********warm start the chip to continue testing****************")
    elif start_mode == 'hot':
        ser.write(b'$PAIR004*3E\r\n')
        print("***********hot start the chip to continue testing****************")
    time.sleep(2)

    ser.reset_input_buffer()
    time_step_factor = 1
    check_times = 1
    while not get_gnss_fix_status(ser, trial_times=check_times, trial_interval=10, percentage=1):
        # print(f"------------------Test acquiring sensitivity at {start_mode} start-------------------")
        console.log(f"[green]------------------Test acquiring sensitivity at {start_mode}"
                    f"start-------------------")
        rprint(f"[green]********GNSS fix status:[/green][red] not fixed yet[/red], please wait......")
        sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
        # print(f"\n**********Acquiring sensitivity at {start_mode} start mode: {sensitivity}dBm")
        print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz")
        print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz\n")
        if sv_num_l1 == 0:
            time_step_factor = 1
        elif 0 < sv_num_l1 < 4:
            time_step_factor = 2
        elif sv_num_l1 >= 4:
            time_step_factor = 2.5
        step = step + 1
        # fix_interval = step*3
        power = acquiring_power_table_at_cold_start[step]
        # power = acquiring_power_table[start_mode][step]
        gnss_test.Set_Power(power)
        rprint(f'[blue]*********Set GPS Power: {float(gnss_test.Get_Power()) - attenuation}dBm and test for '
              f'{120*time_step_factor} secs......')
        check_times = int(120*time_step_factor/10)
        # serial_port_wait(120*time_step_factor, ser)
        ser.reset_input_buffer()
    rprint('**************GNSS fix status: [green]fixed![/green] test done!!')
    sensitivity = acquiring_power_table[start_mode][step]-attenuation
    ser.reset_input_buffer()
    sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
    console.log(f"[green]\n**********Acquiring sensitivity at {start_mode} start mode: {sensitivity}dBm")
    print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz")
    print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz\n")

    # ser.close()
    # gnss_test.Close()
    return sensitivity


def gps_get_tracking_sensitivity():
    """

    :return: sensitivity
    """
    global gnss_test
    console.log("[black on red]------------------Get CNR values at different output powers-------------------")
    CNR_power_table = [i + attenuation for i in power_table]
    # step = 0
    CNR_time_table = [500, 60, 60, 60, 60, 60, 60]
    for step in range(7):
        rprint("[green]------------------Get CNR values at different output powers-------------------")
        gnss_test.Set_Power(CNR_power_table[step])
        rprint(f'\n[blue]*********Set GPS Power: {float(gnss_test.Get_Power()) - attenuation}dBm and wait '
              f'{CNR_time_table[step]} secs......')
        print(f'\n*********Set GPS Power: {float(gnss_test.Get_Power()) - attenuation}dBm and wait '
              f'{CNR_time_table[step]} secs......', file=log_file)
        serial_port_wait(CNR_time_table[step], ser)
        ser.reset_input_buffer()
        sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
        # print(f"\n**********GNSS Power: {float(gnss_test.Get_Power()) - attenuation}dBm")
        print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz")
        print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz\n")

        print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz", file=log_file)
        print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz\n", file=log_file)

    console.log("[black on red]------------------Test tracking sensitivity-------------------")
    # print("------------------Test tracking sensitivity-------------------", file=log_file)
    step = 0
    # time_step_factor = 1
    # ser.reset_input_buffer()
    # interval = 500
    tracking_power_table = [-155, -156, -157, -158, -158.5, -159, -159.5, -160, -160.5, -161, 161.5, -162, -162.5, -163,
                            -163.5, -164, -164.5, -165, -165.5, -166, -166.5, -167]
    tracking_power_table = [i+attenuation for i in tracking_power_table]
    # # cold start the chip
    # print("\n********Cold start the gnss chip")
    # ser.write(b'$PAIR006*3C\r\n')
    # time.sleep(2)
    """Initiate smbv100b and set dual-band mode"""
    gnss_test.Set_Power(tracking_power_table[step])

    print(f'Frequency: {gnss_test.Get_Freq() / 1e9}GHz')
    # gnss_test.Set_Freq(1.389225e9)
    print(f'L5 state: {gnss_test.Get_l5_state()}')
    print(f'GPS Power: {float(gnss_test.Get_Power())-attenuation}dBm')
    # print(f'GPS Power: {float(gnss_test.Get_Power())-attenuation}dBm', file=log_file)
    # print(f'CNR: {gnss_test.Get_CNRatio()}')
    interval = 60
    print("*******Initialize the device for 30 secs**************")
    serial_port_wait(30, ser)
    while get_gnss_fix_status(ser, trial_times=1, trial_interval=interval, percentage=1):
        rprint("[green]------------------Test tracking sensitivity-------------------")
        rprint(f'********GNSS fix status: [green]fixed')
        ser.reset_input_buffer()
        sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
        console.log(f"[green]**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz")
        # print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz", file=log_file)
        console.log(f"[green]**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz")
        step = step + 1
        # interval = step*5
        power = tracking_power_table[step]
        gnss_test.Set_Power(power)
        rprint(f'\n[green]**********Set GPS Power: {float(gnss_test.Get_Power())-attenuation}dBm and'
              f' wait {60}secs......')

    rprint('***************GNSS fix status: [red]not fixed![/red] test done.***************')
    # print('**********GNSS fix status: not fixed! test done.***************\n', file=log_file)
    measured_tracking_sensitivity = tracking_power_table[step-1]-attenuation
    ser.reset_input_buffer()
    sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
    console.log(f"[green]**********Tracking sensitivity: {measured_tracking_sensitivity}dBm")
    print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz")
    print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz\n")
    """
    Get reacquiring sensitivity
    """
    console.log("[black on red]------------------Test re-acquiring sensitivity-------------------")
    # reacquiring_power_table = [-170, -165, -164.5, -164, -163.5, -163, -162.5, -162, -161.5, -161, -160.5, -160,
    #                            -159.5, -159]
    reacquiring_power_table = [-170, -160, -159.5, -159, -158.5, -158, -157.5, -157, -156.5, -156, -155.5, -155, -154.5,
                               -154]
    reacquiring_time_table = [300, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120]
    step = 0
    time_step_factor = 1
    reacquiring_power_table = [i+attenuation for i in reacquiring_power_table]
    power = reacquiring_power_table[step]
    gnss_test.Set_Power(power)
    rprint(f'\n[green]**********Set GPS Power: {float(gnss_test.Get_Power()) - attenuation}dBm and'
          f' wait 300 secs......')
    serial_port_wait(reacquiring_time_table[step], ser)
    # interval = 10
    check_times = 1
    while not get_gnss_fix_status(ser, trial_times=check_times, trial_interval=10, percentage=1):
        rprint("[green]------------------Test re-acquiring sensitivity-------------------")
        rprint(f"[green]********GNSS fix status:[/green][red] not fixed yet[/red], please wait......")
        ser.reset_input_buffer()
        sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
        print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz")
        # print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz", file=log_file)
        print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz")
        # print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz", file=log_file)
        if sv_num_l1 == 0:
            time_step_factor = 1
        elif 0 < sv_num_l1 < 4:
            time_step_factor = 2
        elif sv_num_l1 >= 4:
            time_step_factor = 2.5
        step = step + 1
        # interval = step*3
        power = reacquiring_power_table[step]
        gnss_test.Set_Power(power)
        rprint(f'\n[green]**********Set GPS Power: {float(gnss_test.Get_Power())-attenuation}dBm and'
              f' test for {reacquiring_time_table[step]*time_step_factor} secs......')
        check_times = int(reacquiring_time_table[step]*time_step_factor/10)
        # serial_port_wait(reacquiring_time_table[step]*time_step_factor, ser)
        time.sleep(3)
        ser.reset_input_buffer()
    rprint('***************GNSS fix status: [green]fixed![/green] test done.***************')
    # print('**********GNSS fix status: fixed! test done.***************\n', file=log_file)
    measured_reacquiring_sensitivity = reacquiring_power_table[step]-attenuation
    ser.reset_input_buffer()
    # sv_num_l1, l1_cn_avg, sv_num_l5, l5_cn_avg = parse_nmea_sentences(ser)
    console.log(f"[green]\n**********Reacquiring sensitivity: {measured_reacquiring_sensitivity}dBm")
    print(f"**********L1 SV number: {sv_num_l1}, average cnr {l1_cn_avg}dBHz")
    print(f"**********L5 SV number: {sv_num_l5}, average cnr {l5_cn_avg}dBHz\n")
    return measured_tracking_sensitivity, measured_reacquiring_sensitivity


def wifi_init_test(standard="BSTD"):
    global wifi_sig_test
    wifi_sig_test.Set_Source_state(state="OFF")
    wifi_sig_test.Set_Standard(standard=standard)
    # wifi_sig_test.Set_PER_ModulationCodeRate(rate=rate)
    # wifi_sig_test.Preset()
    # wifi_sig_test.Init_Connection_SupportedRates_DSSS_state()
    wifi_sig_test.Set_PER()
    wifi_sig_test.Set_Source_state(state='ON')


def wifi_connect_dut():
    global wifi_sig_test
    print("*************Wait dut to connect**********************")
    while wifi_sig_test.Get_ConnectionStatus() != "ASS":
        print("*****************Connection status: IDLE")
        time.sleep(5.0)
    print("*****************Connection status: ASS")
    print("*****************")


def wifi_get_Tx_power_by_channel(ch):
    """
    :param ch: channel number in string
    :return:
    """
    wifi_sig_test.Set_Tx_BurstPower()
    wifi_sig_test.Set_Channel(ch=str(ch))
    while wifi_sig_test.Get_ConnectionStatus() != "ASS":
        time.sleep(0.1)
    _, power = wifi_sig_test.Get_PER_Results()
    print(f"**********Tx power of Channel {ch}: {power}dBm")
    return power


def wifi_get_sensitivity_by_channel(channel=1):
    global wifi_power0
    power = wifi_power0
    wifi_sig_test.Set_Tx_BurstPower(power=power)

    last_step = 3
    wifi_sig_test.Set_Channel(ch=str(channel))
    while wifi_sig_test.Get_ConnectionStatus() != "ASS":
        time.sleep(0.1)
    print(f"----Channel: {channel}, standard: {wifi_sig_test.standard} test begins at {datetime.now().now()}------")
    while True:
        print(f"***Set Tx_level: {round(power, 2)}dBm")
        wifi_sig_test.Set_Tx_BurstPower(power=power)
        # time.sleep(2)
        cur_step, per = wifi_get_power_step()

        print(f"***Current per is: {round(per, 3)}%")
        print(f"***Power step: {-round(cur_step, 2)}dB\n")
        if -0.2 < last_step*cur_step < 0:
            if last_step > 0:
                wifi_power0 = power+last_step
                # return bt_power0
            elif last_step < 0:
                wifi_power0 = power
                # return bt_power0
            return wifi_power0
        last_step = cur_step
        power = power - cur_step


def wifi_get_power_step():

    if wifi_sig_test.standard == 'BSTD':
        err = 8
    elif bt_sig_test.burst_type == 'GSTD':
        err = 10
    elif bt_sig_test.burst_type == 'NGFSTD':
        err = 10
    else:
        err = 0

    per0 = wifi_get_per()

    if per0 < 1e-6:
        return 3.0, per0
    """
    when per != 0.0, read 2 more times
    """
    per1 = wifi_get_per()
    per2 = wifi_get_per()

    per = [per0, per1, per2]
    per_arr = np.array(per)
    if np.all(per_arr <= err/5):
        power_step = 1.0
    elif np.any(per_arr > err/5) and np.all(per_arr <= err/2):
        power_step = 0.5
    elif np.any(per_arr > err/2) and np.all(per_arr <= err):
        power_step = 0.2
    elif np.any(per_arr > err) and np.all(per_arr <= 2*err):
        power_step = -0.5
    elif np.any(per_arr >= 2*err):
        power_step = -1.0
    else:
        power_step = None
    return power_step, max(per)


def wifi_get_per():
    per, _ = wifi_sig_test.Get_PER_Results()
    return per


def wifi_get_Tx_power(channel="all"):
    if channel.isdigit():
        channel_range = [int(channel)]
    elif channel.upper() == 'LMH':
        channel_range = range(1, 14, 6)
    elif channel.upper() == 'ALL':
        channel_range = range(1, 14, 1)
    else:
        raise ValueError("Invalid mode or channel argument")

    for ch in channel_range:
        ch_str = f'CH{ch}'
        wifi_power[ch_str].append(wifi_get_Tx_power_by_channel(ch))


def wifi_get_rx_sensitivity(channel="all"):
    if channel.isdigit():
        channel_range = [int(channel)]
    elif channel.upper() == 'LMH':
        channel_range = range(1, 14, 6)
    elif channel.upper() == 'ALL':
        channel_range = range(1, 14, 1)
    else:
        raise ValueError("Invalid mode or channel argument")

    for ch in channel_range:
        ch_str = f'CH{ch}'
        wifi_sensitivity[ch_str].append(wifi_get_sensitivity_by_channel(ch))


def wifi_tx_test(channel_type='all'):
    global wifi_sig_test, wifi_power
    print(f"--------------------WIFI_Tx test begins at {datetime.now().now()}--------------------")
    wifi_get_Tx_power(channel_type)

    channel_list = list(wifi_power.keys())
    power_list = list(wifi_power.values())

    wb = xw.Book(wifi_rf_file)
    ws = wb.sheets['Tx_power']
    ws.range('E1').value = channel_list
    ws.range(f'E{wifi_standard_inverse_table[wifi_sig_test.standard]+1}').options(transpose=True).value = power_list
    wb.save()
    wb.close()
    xw.App().quit()

    wifi_power = defaultdict(list)


def wifi_rx_test(channel_type='all'):
    global wifi_sig_test, wifi_sensitivity
    print(f"--------------------WIFI_Rx test begins at {datetime.now().now()}--------------------")
    wifi_get_rx_sensitivity(channel_type)

    channel_list = list(wifi_sensitivity.keys())
    sen_list = list(wifi_sensitivity.values())

    wb = xw.Book(wifi_rf_file)
    ws = wb.sheets['Rx_power']
    ws.range('E1').value = channel_list
    ws.range(f'E{wifi_standard_inverse_table[wifi_sig_test.standard] + 1}').options(transpose=True).value = sen_list
    wb.save()
    wb.close()
    xw.App().quit()

    wifi_sensitivity = defaultdict(list)


def wifi_test(measurement_type='1', channel_type='all'):
    measurement_actions = {
        '1': lambda: wifi_tx_test(channel_type),
        '2': lambda: wifi_rx_test(channel_type),
        '3': lambda: (wifi_tx_test(channel_type), wifi_rx_test(channel_type))
    }

    try:
        measurement_actions[measurement_type]()
    except KeyError:
        raise ValueError(f'Invalid measurement type: {measurement_type}')


if __name__ == '__main__':

    if os.path.exists("gps_test_log.txt"):
        os.remove("gps_test_log.txt")
    log_file = open("gps_test_log.txt", 'a')
    instr, ip_addr = check_instrument_info()

    if instr == "SMBV100B":
        start_time = datetime.now()
        ser = serial.Serial(port=port, baudrate=baud_rate, timeout=1)
        gnss_test = GnssConduction(ip_addr)
        gnss_test.write("*RST")
        gnss_test.Set_l5_state('ON')
        # gnss_test.Set_GPS_L5_PowerOffset()
        gnss_test.Set_baseband_state('ON')
        gnss_test.Set_IQMod('ON')
        gnss_test.Set_Digital_attenuation(level=attenuation)
        gnss_test.Set_RFState('ON')
        acquiring_sensitivity_at_cold_start = gps_get_acquiring_sensitivity()
        end_time = datetime.now()
        print("========================================================")
        print("**********************Duration: {}".format(end_time - start_time))
        print("========================================================")
        tracking_sensitivity, reacquiring_sensitivity = gps_get_tracking_sensitivity()
        end_time = datetime.now()
        print("========================================================")
        print("**********************Duration: {}".format(end_time - start_time))
        print("========================================================")
        # acquiring_sensitivity_at_hot_start = gps_get_acquiring_sensitivity(start_mode='hot')
        # ttff_at_cold_start = round(gps_get_ttff(start_mode='cold'), 2)
        # ttff_at_hot_start = round(gps_get_ttff(start_mode='hot'), 2)
        # gps_get_acquiring_sensitivity(start_mode='hot')
        print("\n***************All measurements are done*********************\n")
        print(f"*********Tracking sensitivity ---> {tracking_sensitivity}dBm*********\n")
        print(f"*********Tracking sensitivity ---> {tracking_sensitivity}dBm*********\n", file=log_file)
        print(f"*********Reacquiring sensitivity ---> {reacquiring_sensitivity}dBm*********\n")
        print(f"*********Reacquiring sensitivity ---> {reacquiring_sensitivity}dBm*********\n", file=log_file)
        print(f"******Acquiring sensitivity @cold start ---> {acquiring_sensitivity_at_cold_start}dBm******\n")
        print(f"******Acquiring sensitivity @cold start ---> {acquiring_sensitivity_at_cold_start}dBm******\n",
              file=log_file)
        # print(f"******Acquiring sensitivity @hot start ---> {acquiring_sensitivity_at_hot_start}dBm******\n")
        # print(f"******Acquiring sensitivity @hot start ---> {acquiring_sensitivity_at_hot_start}dBm******\n",
        #       file=log_file)
        # print(f"************ttff @cold start ---> {ttff_at_cold_start}secs***************\n")
        # print(f"************ttff @cold start ---> {ttff_at_cold_start}secs***************\n", file=log_file)
        # print(f"************ttff @hot start ---> {ttff_at_hot_start}secs***************\n")
        # print(f"************ttff @hot start ---> {ttff_at_hot_start}secs***************\n", file=log_file)
        ser.close()
        gnss_test.Close()
        end_time = datetime.now()
        print("========================================================")
        print("**********************Duration: {}".format(end_time - start_time))
        print("========================================================")
    elif instr == 'CMW500':
        bt_wifi_selection = 'a'
        root = tk.Tk()
        root.withdraw()
        while bt_wifi_selection != 'E':
            print("\n---------------------------------------------------------------------")
            print("-----------------Please select the type of measurement-----------------")
            print("-----------------------------------------------------------------------")
            print("                    1:       BT\n")
            print("                    2:       WIFI\n")
            print("                    e:       Exit program")
            print('=====================================================================\n')
            bt_wifi_selection = input("Please enter your choice for measurement type: ")
            time.sleep(0.5)
            if bt_wifi_selection.upper() == 'E':
                print("******************************************************************\n")
                print('Exit the program, have a good day!!!')
                time.sleep(3.0)
                sys.exit('>< See you ><')
            elif bt_wifi_selection in ['1', '2']:
                items_selection = 'a'
                while items_selection.upper() != 'E':
                    print("\n---------------------------------------------------------------------")
                    print("-----------------Please select the items of measurement-----------------")
                    print("-----------------------------------------------------------------------")
                    print("                    1:       Tx\n")
                    print("                    2:       Rx\n")
                    print("                    3:       Tx and Rx\n")
                    print("                    b:       Back to Previous\n")
                    print("                    e:       Exit program")
                    print('=====================================================================\n')
                    items_selection = input("Please enter your choice for measurement items: ")
                    time.sleep(0.5)
                    if items_selection.upper == 'E':
                        print("******************************************************************\n")
                        print('Exit the program, have a good day!!!')
                        time.sleep(3.0)
                        sys.exit('>< See you ><')
                    elif items_selection in ['1', '2', '3']:
                        channel_selection = 'a'
                        while channel_selection.upper() != 'E':
                            print("\n-------------------------------------------------------------------")
                            print("------------------Please select the type of channel------------------")
                            print("---------------------------------------------------------------------")
                            print("                    all:     All channels\n")
                            print("                    lmh:     Low_mid_high channels\n")
                            print("                    number:  Single channel\n")
                            print("                    b:       Back to Previous\n")
                            print("                    e:       Exit program")
                            print('=====================================================================')
                            print(f'\nThe type of measurement you have chosen is {measure_bt_or_wifi[bt_wifi_selection]}\n')
                            print(f'\nThe items of measurement you have chosen is {measure_tx_or_rx[items_selection]}\n')
                            channel_selection = input("Now, pick a channel type for test: ")
                            time.sleep(0.5)
                            if channel_selection.upper() in ['ALL', 'LMH'] or channel_selection.isdigit():
                                if bt_wifi_selection == '1':
                                    if bt_create_report() is True:
                                        bt_sig_test = BluetoothSignaling(ip_addr)
                                        bt_sig_test.Set_State('ON')
                                        bt_sig_test.Set_ExpectedPower(20)
                                        print('Trying to connect a bt eut.........')
                                        bt_connect_eut()
                                        bt_test(measurement_type=items_selection, channel_type=channel_selection)
                                        bt_sig_test.Close()
                                        print('\nBluetooth signaling test has been completed, backing to main menu\n')
                                        items_selection = 'b'
                                        break
                                    else:
                                        print('\nFailed to create report, back to channel menu\n')
                                        continue
                                elif bt_wifi_selection == '2':
                                    wifi_standard_selection = 'a'
                                    wifi_report = False
                                    while wifi_standard_selection.upper() != 'E':
                                        print("\n-------------------------------------------------------------------")
                                        print("------------------Please select the standard of wifi------------------")
                                        print("---------------------------------------------------------------------")
                                        print("                    1:       802.11b\n")
                                        print("                    2:       802.11g\n")
                                        print("                    3:       802.11n\n")
                                        print("                    b:       Back to Previous\n")
                                        print("                    e:       Exit program")
                                        print('=====================================================================')
                                        wifi_standard_selection = input("Now, pick a wifi standard for test: ")
                                        if wifi_standard_selection in ['1', '2', '3']:
                                            if wifi_report is not True:
                                                if wifi_create_report() is True:
                                                    wifi_report = True
                                                else:
                                                    print('\nFailed to create report, back to channel menu\n')
                                                    continue
                                            wifi_sig_test = WifiSignaling(ip_addr)
                                            # print("init done!!!")
                                            wifi_init_test(standard=wifi_standard_table[wifi_standard_selection])
                                            wifi_connect_dut()
                                            time.sleep(1.0)
                                            wifi_test(measurement_type=items_selection,
                                                      channel_type=channel_selection)
                                            # wifi_sig_test.jav_Clear()
                                            wifi_sig_test.Close()
                                            print(f'\nWifi signaling test'
                                                  f'({wifi_standard_table_for_print[wifi_standard_selection]}) '
                                                  f'has been completed, '
                                                  'backing to standard menu, '
                                                  'you can pick a standard to test '
                                                  'without re-selecting file directories')
                                            continue
                                        elif wifi_standard_selection.upper() == 'E':
                                            print(
                                                "******************************************************************\n")
                                            print('Exit the program, have a good day!!!')
                                            time.sleep(3.0)
                                            sys.exit('>< See you ><')
                                        elif wifi_standard_selection.upper() == 'B':
                                            print('\nBack to previous menu')
                                            break
                                else:
                                    pass
                            elif channel_selection.upper() == 'B':
                                print('\nBack to previous menu')
                                break
                            elif channel_selection.upper() == 'E':
                                print("******************************************************************\n")
                                print('Exit the program, have a good day!!!')
                                time.sleep(3.0)
                                sys.exit('See you ^_^')
                            else:
                                print('\nInvalid input, try again O_O !!!')
                                continue
                    elif items_selection.upper == 'B':
                        print('\nBack to main menu')
                        break
                    else:
                        print('\nInvalid input, try again O_O !!!')
                        continue
            else:
                print('\nInvalid input, try again O_O !!!')
                continue
    else:
        pass
    # log_file.close()
    # sys.stdout = sys.__stdout__
